package com.colortrap.game;

/**
 * Reliable saving: checksummed primary + previous-good backup. Survives corruption,
 * truncated writes and tampering. Storage is abstracted so this runs in unit tests.
 */
public final class SaveManager {
    public interface Store { String get(String key); boolean put(String key, String value); }
    public static final String MAIN = "main", BAK = "bak";
    public boolean recovered, lastOk = true;
    private final Store store; private String lastGood;

    public SaveManager(Store s) { store = s; }

    static String sum(String s) { long h = 5381; for (int i = 0; i < s.length(); i++) h = ((h * 33) ^ s.charAt(i)) & 0xFFFFFFFFL; return Long.toString(h, 36); }
    private static String wrap(String body) { return sum(body) + "\n" + body; }
    private static String unwrap(String raw) {
        if (raw == null) return null; int i = raw.indexOf('\n'); if (i < 0) return null;
        String body = raw.substring(i + 1); return sum(body).equals(raw.substring(0, i)) ? body : null;
    }
    public Profile load() {
        String a = unwrap(store.get(MAIN)), b = unwrap(store.get(BAK));
        if (a == null && store.get(MAIN) != null && b != null) recovered = true;
        String body = a != null ? a : b;
        Profile p = Profile.parse(body); lastGood = a != null ? store.get(MAIN) : (b != null ? store.get(BAK) : null); return p;
    }
    public boolean save(Profile p) {
        String blob = wrap(p.serialize());
        if (lastGood != null) store.put(BAK, lastGood);
        boolean ok = store.put(MAIN, blob); if (ok) lastGood = blob; lastOk = ok; return ok;
    }
}
