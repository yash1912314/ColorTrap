package com.colortrap.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

/** Native host: owns the profile, save system, sound and ads; the whole game is drawn by GameView. */
public class MainActivity extends ComponentActivity implements GameView.Host {
    private Profile profile; private SaveManager saver; private Sfx sfx; private Ads ads; private GameView view; private Vibrator vibrator; private SharedPreferences prefs;

    private final SaveManager.Store store = new SaveManager.Store() {
        @Override public String get(String k) { return prefs.getString(k, null); }
        @Override public boolean put(String k, String v) { try { return prefs.edit().putString(k, v).commit(); } catch (Exception e) { return false; } }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);                  // edge-to-edge (enforced on Android 15+)
        prefs = getSharedPreferences("colortrap_native", Context.MODE_PRIVATE);
        saver = new SaveManager(store); profile = saver.load();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        sfx = new Sfx(this); sfx.enabled = profile.snd;

        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFF0F1122);
        FrameLayout bannerHost = new FrameLayout(this);
        ads = new Ads(this, bannerHost, () -> profile);
        view = new GameView(this, this);
        root.addView(view, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(bannerHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, 0, bars.right, bars.bottom); view.setInsets(bars.top, 0); return WindowInsetsCompat.CONSUMED;
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { if (!view.onBack()) { setEnabled(false); getOnBackPressedDispatcher().onBackPressed(); } }   // game handles it first
        });
        ads.init();
    }
    @Override protected void onPause() { view.onAppPause(); save(); ads.pause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); view.onAppResume(); ads.resume(); }
    @Override protected void onDestroy() { ads.destroy(); sfx.release(); super.onDestroy(); }

    /* ---- GameView.Host ---- */
    @Override public Profile profile() { return profile; }
    @Override public void save() { saver.save(profile); }
    @Override public Ads ads() { return ads; }
    @Override public Sfx sfx() { return sfx; }
    @Override public void exitApp() { finish(); }
    @Override public void resetProgress() { prefs.edit().clear().commit(); profile = new Profile(); saver = new SaveManager(store); saver.save(profile); sfx.enabled = true; }
    @Override public void vibrate(long ms) {
        if (vibrator == null) return;
        try { if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)); else vibrator.vibrate(ms); } catch (Exception ignored) { }
    }
}
