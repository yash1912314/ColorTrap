package com.colortrap.game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * Pure game rules + solver (no Android dependencies, unit-tested on a plain JVM).
 * Faithful port of the verified web engine (js/engine.js).
 */
public final class Engine {
    private Engine() {}
    public static final int CAP = 4, LEVELS = 150;

    /* ---------------- RNG: mulberry32, identical output to the JS version ---------------- */
    public static final class Rng {
        private int r;
        public Rng(long seed) { r = (int) seed; }
        public double next() {
            r += 0x6D2B79F5;
            int t = (r ^ (r >>> 15)) * (1 | r);
            t = (t + ((t ^ (t >>> 7)) * (61 | t))) ^ t;
            return ((t ^ (t >>> 14)) & 0xFFFFFFFFL) / 4294967296.0;
        }
    }
    public static int hashStr(String s) { int a = 7; for (int i = 0; i < s.length(); i++) a = a * 31 + s.charAt(i); return a; }

    /* ---------------- board ---------------- */
    public static final class Board {
        public int n; public int[][] b; public int[] len;
        public Board(int n) { this.n = n; b = new int[n][CAP]; len = new int[n]; }
        public Board copy() { Board c = new Board(n); for (int i = 0; i < n; i++) { System.arraycopy(b[i], 0, c.b[i], 0, CAP); c.len[i] = len[i]; } return c; }
        public int top(int i) { return b[i][len[i] - 1]; }
        public boolean mono(int i) { if (len[i] == 0) return false; for (int k = 1; k < len[i]; k++) if (b[i][k] != b[i][0]) return false; return true; }
        public boolean full(int i) { return len[i] == CAP && mono(i); }
        public void addTube() { b = Arrays.copyOf(b, n + 1); b[n] = new int[CAP]; len = Arrays.copyOf(len, n + 1); n++; }
        public boolean anyFull() { for (int i = 0; i < n; i++) if (full(i)) return true; return false; }
    }

    /** Board plus obstacle/move context. */
    public static final class State {
        public Board T; public int moves; public boolean unl; public int[] lock = new int[0]; public int[] frz = new int[0];
        public State copy() { State s = new State(); s.T = T.copy(); s.moves = moves; s.unl = unl; s.lock = lock; s.frz = frz; return s; }
    }

    public static boolean isLocked(State s, int i) { if (s.unl) return false; for (int x : s.lock) if (x == i) return true; return false; }
    public static int frozenLeft(State s, int i) { int k = i < s.frz.length ? s.frz[i] : 0; return k > 0 ? Math.max(0, k - s.moves) : 0; }
    public static boolean sealed(State s, int i) { return isLocked(s, i) || frozenLeft(s, i) > 0; }

    /** How many balls would move i -> j (0 = illegal). */
    public static int pourN(State s, int i, int j) {
        Board T = s.T;
        if (i == j || T.len[i] == 0 || T.len[j] >= CAP) return 0;
        if (sealed(s, i) || sealed(s, j)) return 0;
        int c = T.top(i);
        if (T.len[j] > 0 && T.top(j) != c) return 0;
        int n = 0;
        while (n < T.len[i] && T.b[i][T.len[i] - 1 - n] == c && T.len[j] + n < CAP) n++;
        return n;
    }
    /** Performs the pour; returns balls moved. */
    public static int doPour(State s, int i, int j) {
        int n = pourN(s, i, j); Board T = s.T;
        for (int k = 0; k < n; k++) { T.b[j][T.len[j]++] = T.b[i][--T.len[i]]; }
        s.moves++;
        if (!s.unl && T.anyFull()) s.unl = true;
        return n;
    }
    public static boolean isWon(Board T) {
        int mask = 0, filled = 0;
        for (int i = 0; i < T.n; i++) { if (T.len[i] == 0) continue; if (!T.mono(i)) return false; filled++; mask |= 1 << T.b[i][0]; }
        return filled == Integer.bitCount(mask);
    }
    public static boolean anyMove(State s) { for (int i = 0; i < s.T.n; i++) for (int j = 0; j < s.T.n; j++) if (pourN(s, i, j) > 0) return true; return false; }

    /* ---------------- solver (DFS + memo + move ordering) ---------------- */
    public static final class Solve { public boolean ok, capped; public int[][] moves; public int nodes; }

    public static Solve solve(State s0, int maxNodes) {
        final Solve res = new Solve(); final State root = s0.copy();
        int mt = 0; for (int k : root.frz) mt = Math.max(mt, k); final int maxThaw = mt;
        final HashSet<String> seen = new HashSet<>(); final ArrayList<int[]> path = new ArrayList<>();
        final int[] nodes = {0};
        class Dfs {
            boolean run(State s) {
                if (isWon(s.T)) return true;
                if (++nodes[0] > maxNodes) return false;
                String k = key(s, maxThaw); if (!seen.add(k)) return false;
                ArrayList<int[]> mv = new ArrayList<>();
                Board T = s.T;
                for (int i = 0; i < T.n; i++) {
                    if (T.len[i] == 0 || T.full(i) || sealed(s, i)) continue;
                    for (int j = 0; j < T.n; j++) {
                        int n = pourN(s, i, j); if (n == 0) continue;
                        if (T.len[j] == 0 && T.mono(i) && n == T.len[i]) continue;      // pointless: mono tube -> empty
                        int sc = 0;
                        if (T.len[j] > 0 && T.len[j] + n == CAP && T.mono(j)) sc += 60;  // completes a tube
                        if (T.len[j] > 0) sc += 25;
                        if (T.len[i] > n && T.b[i][T.len[i] - n - 1] == T.top(i)) sc -= 5;
                        if (T.len[i] == n) sc += 15;
                        if (T.len[j] == 0) sc -= 20;
                        mv.add(new int[]{i, j, sc});
                    }
                }
                mv.sort((a, b) -> b[2] - a[2]);
                for (int[] m : mv) {
                    State c = s.copy(); doPour(c, m[0], m[1]);
                    path.add(new int[]{m[0], m[1]});
                    if (run(c)) return true;
                    path.remove(path.size() - 1);
                    if (nodes[0] > maxNodes) return false;
                }
                return false;
            }
        }
        res.ok = new Dfs().run(root); res.nodes = nodes[0]; res.capped = !res.ok && nodes[0] > maxNodes;
        if (res.ok) res.moves = path.toArray(new int[0][]);
        return res;
    }
    private static String key(State s, int maxThaw) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.T.n; i++) { for (int k = 0; k < s.T.len[i]; k++) sb.append((char) ('a' + s.T.b[i][k])); sb.append('|'); }
        if (s.unl) sb.append('U'); sb.append(Math.min(s.moves, maxThaw)); return sb.toString();
    }
    /** Next hint from any live position: solver first, simple heuristic fallback. */
    public static int[] hintMove(State s) {
        Solve r = solve(s, 30000);
        if (r.ok && r.moves.length > 0) return r.moves[0];
        for (int i = 0; i < s.T.n; i++) for (int j = 0; j < s.T.n; j++)
            if (pourN(s, i, j) > 0 && !s.T.full(i) && !(s.T.len[j] == 0 && s.T.mono(i))) return new int[]{i, j};
        return null;
    }

    /* ---------------- generator used by the daily puzzle ---------------- */
    public static Board shuffleLayout(long seed, int c, double d, int empties) {
        Rng rnd = new Rng(seed); int[] ball = new int[c * CAP];
        for (int k = 0; k < c; k++) for (int i = 0; i < CAP; i++) ball[k * CAP + i] = k;
        int want = d > 0 ? 1 + (int) Math.round(d * 120) : 1, ok = 0, bs = Integer.MAX_VALUE;
        Board best = null, T = null;
        for (int n = 0; n < 600 && ok < want; n++) {
            for (int i = ball.length - 1; i > 0; i--) { int j = (int) (rnd.next() * (i + 1)); int t = ball[i]; ball[i] = ball[j]; ball[j] = t; }
            T = new Board(c + empties);
            for (int k = 0; k < c; k++) { for (int q = 0; q < CAP; q++) T.b[k][q] = ball[k * CAP + q]; T.len[k] = CAP; }
            boolean bad = false; for (int i = 0; i < T.n; i++) if (T.len[i] > 0 && T.mono(i)) { bad = true; break; }
            if (bad) continue;
            ok++; int sc = 0;
            for (int i = 0; i < T.n; i++) for (int q = 1; q < T.len[i]; q++) if (T.b[i][q] == T.b[i][q - 1]) sc++;
            if (sc < bs) { bs = sc; best = T; }
            if (sc == 0) break;
        }
        return best != null ? best : T;
    }
    public static Board dailyBoard(String date) {
        int h = hashStr(date);
        for (int k = 0; k < 20; k++) {
            Board T = shuffleLayout(h + (long) k * 977, 4, 0, 2); State s = new State(); s.T = T;
            if (solve(s, 120000).ok) return T;
        }
        return shuffleLayout(h, 4, 0, 3);
    }

    /* ---------------- levels (loaded from assets/levels.txt) ---------------- */
    public static final class Level {
        public int n, c, par, limitMoves, limitTime; public boolean boss; public String[] mods; public int[] lock, frz; public Board T; public int[][] sol;
        public boolean has(String m) { for (String x : mods) if (x.equals(m)) return true; return false; }
        public State newState() { State s = new State(); s.T = T.copy(); s.lock = lock; s.frz = frz; return s; }
        public boolean challenge() { return has("moves") || has("time") || has("noundo") || has("nohint") || boss; }
    }
    private static int[] ints(String s) { if (s.equals("-")) return new int[0]; String[] p = s.split(","); int[] r = new int[p.length]; for (int i = 0; i < p.length; i++) r[i] = Integer.parseInt(p[i]); return r; }
    public static Level[] parseLevels(String text) {
        Level[] out = new Level[LEVELS + 1];
        for (String line : text.split("\n")) {
            if (line.isEmpty()) continue;
            String[] f = line.split(";"); Level L = new Level();
            L.n = Integer.parseInt(f[0]); L.c = Integer.parseInt(f[1]); L.mods = f[2].equals("-") ? new String[0] : f[2].split(",");
            L.par = Integer.parseInt(f[3]); L.limitMoves = Integer.parseInt(f[4]); L.limitTime = Integer.parseInt(f[5]); L.lock = ints(f[6]);
            String[] tubes = f[8].split("/"); L.T = new Board(tubes.length);
            for (int i = 0; i < tubes.length; i++) if (!tubes[i].equals("_")) { int[] bs = ints(tubes[i]); for (int k = 0; k < bs.length; k++) L.T.b[i][k] = bs[k]; L.T.len[i] = bs.length; }
            L.frz = new int[tubes.length];
            if (!f[7].equals("-")) for (String kv : f[7].split(",")) { String[] p = kv.split(":"); L.frz[Integer.parseInt(p[0])] = Integer.parseInt(p[1]); }
            for (String m : L.mods) if (m.equals("boss")) L.boss = true;
            if (f.length > 9 && !f[9].equals("-")) { String s = f[9]; L.sol = new int[s.length() / 2][2]; for (int i = 0; i < L.sol.length; i++) { L.sol[i][0] = Integer.parseInt(s.substring(2 * i, 2 * i + 1), 36); L.sol[i][1] = Integer.parseInt(s.substring(2 * i + 1, 2 * i + 2), 36); } }
            else L.sol = new int[0][];
            out[L.n] = L;
        }
        return out;
    }
}
