package com.colortrap.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.OverScroller;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/**
 * The whole game UI, drawn natively on a Canvas (no WebView, no HTML).
 * Immediate-mode: every frame the current screen draws itself and registers tap targets.
 */
public class GameView extends View {
    public interface Host { Profile profile(); void save(); void vibrate(long ms); Ads ads(); Sfx sfx(); void exitApp(); void resetProgress(); }

    static final int SPLASH = 0, HOME = 1, LEVELS = 2, GAME = 3, SHOP = 4, MISSIONS = 5, SETTINGS = 6, DAILY = 7;
    static final int D_NONE = 0, D_PAUSE = 1, D_WIN = 2, D_FAIL = 3, D_STUCK = 4, D_BRIEF = 5, D_OFFER = 6;
    static final String VERSION = "7.0.0";

    final Host host; final Ui ui; final Engine.Level[] levels;
    final float d;
    int W, H; float insetT, insetB;
    float now, dt, lastFrame, appPausedAt;
    int screen = SPLASH; float screenT;
    int dlg = D_NONE; String dlgArg = ""; float dlgT;

    /* ---- tap targets ---- */
    static final int MAXH = 160; final float[] hl = new float[MAXH], ht = new float[MAXH], hr = new float[MAXH], hb = new float[MAXH]; final String[] ha = new String[MAXH]; final int[] hg = new int[MAXH]; int hn; boolean hitsOn = true;
    float clipT = -1e9f, clipB = 1e9f; float hitOffY;
    String pressAct; int pressArg; float downX, downY, lastY; boolean dragging; VelocityTracker vt; final OverScroller scroller; final int slop;
    float scrollY, contentH, viewTop, viewBottom; boolean centerLevels;

    final Fx.Particles fx = new Fx.Particles(500);
    final RectF rf = new RectF(), rf2 = new RectF(); final Path path = new Path(); final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
    String toastMsg = ""; float toastT = -10; final ArrayList<String> toastQ = new ArrayList<>(); float toastNext;

    /* ---- theme caches ---- */
    String themeName = ""; int themeIdx; final Shader[] ballSh = new Shader[14]; final int[] ballCol = new int[14];
    String backName = ""; int backIdx; Shader bgGlow; int bgW, bgH;
    final SimpleDateFormat dayFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    public GameView(Context ctx, Host h) {
        super(ctx); host = h; d = ctx.getResources().getDisplayMetrics().density; ui = new Ui(d); slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        scroller = new OverScroller(ctx); setFocusable(true);
        String txt = ""; try { InputStream in = ctx.getAssets().open("levels.txt"); ByteArrayOutputStream bo = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); txt = bo.toString("UTF-8"); in.close(); } catch (Exception e) { }
        levels = Engine.parseLevels(txt); screenT = now = SystemClock.uptimeMillis() / 1000f;
    }
    Profile P() { return host.profile(); }
    float dp(float v) { return v * d; }
    String today() { return dayFmt.format(Calendar.getInstance().getTime()); }
    String weekId() { Calendar c = Calendar.getInstance(); c.setFirstDayOfWeek(Calendar.MONDAY); c.setMinimalDaysInFirstWeek(4); return c.getWeekYear() + "-W" + String.format(Locale.US, "%02d", c.get(Calendar.WEEK_OF_YEAR)); }
    void sfx(int s) { host.sfx().play(s); }
    void vib(long ms) { if (P().vib && !P().rm) host.vibrate(ms); }
    void toast(String s) { toastMsg = s; toastT = now; }
    void queueToast(String s) { toastQ.add(s); }

    /* ======================= frame loop ======================= */
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { W = w; H = h; bgGlow = null; }
    public void setInsets(float top, float bottom) { insetT = top; insetB = bottom; }

    @Override protected void onDraw(Canvas c) {
        float t = SystemClock.uptimeMillis() / 1000f; dt = lastFrame == 0 ? .016f : Math.min(.05f, t - lastFrame); lastFrame = t; now = t; W = getWidth(); H = getHeight();
        syncTheme(); update();
        hn = 0; clipT = -1e9f; clipB = 1e9f; hitOffY = 0;
        drawBackground(c);
        float a = Fx.easeOutCubic((now - screenT) / .32f); boolean fading = a < 1;
        if (fading) c.saveLayerAlpha(0, 0, W, H, (int) (255 * a)); c.save(); if (fading) c.translate(0, (1 - a) * dp(22));
        hitsOn = dlg == D_NONE && a > .6f;
        switch (screen) { case SPLASH: drawSplash(c); break; case HOME: drawHome(c); break; case LEVELS: drawLevels(c); break; case GAME: drawGame(c); break; case SHOP: drawShop(c); break; case MISSIONS: drawMissions(c); break; case SETTINGS: drawSettings(c); break; case DAILY: drawDaily(c); break; }
        c.restore(); if (fading) c.restore();
        if (dlg != D_NONE) { hitsOn = true; clipT = -1e9f; clipB = 1e9f; hitOffY = 0; drawDialog(c); }
        drawParticles(c); drawToast(c);
        postInvalidateOnAnimation();
    }
    void update() {
        fx.update(dt, dp(900));
        if (screen == SPLASH && now - screenT > 1.6f) goTo(HOME);
        if (scroller.computeScrollOffset()) { scrollY = scroller.getCurrY(); }
        if (!(screen == LEVELS && centerLevels)) clampScroll();
        if (toastQ.size() > 0 && now - toastT > 2.1f && now >= toastNext) { toast(toastQ.remove(0)); }
        if (screen == GAME) updateGame();
    }
    void clampScroll() { float max = Math.max(0, contentH - (viewBottom - viewTop)); if (scrollY < 0) scrollY = 0; if (scrollY > max) scrollY = max; }

    void syncTheme() {
        Profile p = P();
        if (!p.theme.equals(themeName)) {
            themeName = p.theme; themeIdx = 0; for (int i = 0; i < Catalog.THEMES.length; i++) if (Catalog.THEMES[i].equals(themeName)) themeIdx = i;
            for (int i = 0; i < 14; i++) { int b = Catalog.THEME_COLORS[themeIdx][i]; ballCol[i] = b; ballSh[i] = new RadialGradient(-.3f, -.35f, 1.45f, new int[]{mix(b, 0xFFFFFFFF, .6f), b, mix(b, 0xFF000000, .5f)}, new float[]{0, .5f, 1}, Shader.TileMode.CLAMP); }
        }
        if (!p.back.equals(backName)) { backName = p.back; backIdx = 0; for (int i = 0; i < Catalog.BACKS.length; i++) if (Catalog.BACKS[i].equals(backName)) backIdx = i; bgGlow = null; }
    }
    static int mix(int a, int b, float t) { int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t); return 0xFF000000 | r << 16 | g << 8 | bl; }
    static int alpha(int col, float a) { return ((int) (((col >>> 24) & 255) * Fx.clamp01(a)) << 24) | (col & 0xFFFFFF); }

    void drawBackground(Canvas c) {
        int[] bc = Catalog.BACK_COLORS[backIdx]; bp.setShader(null); bp.setStyle(Paint.Style.FILL); bp.setColor(bc[0]); c.drawRect(0, 0, W, H, bp);
        if (bgGlow == null || bgW != W || bgH != H) { bgW = W; bgH = H; bgGlow = new RadialGradient(W / 2f, H * .12f, Math.max(W, H) * .85f, alpha(bc[1], .75f), alpha(bc[1], 0), Shader.TileMode.CLAMP); }
        bp.setShader(bgGlow); c.drawRect(0, 0, W, H, bp); bp.setShader(null);
        if (P().rm) return;
        for (int i = 0; i < 7; i++) {                                   // slow drifting bokeh
            float fx0 = (float) (Math.abs(Math.sin(i * 12.9898)) % 1), x = W * (.08f + .84f * fx0) + (float) Math.sin(now * .15f + i) * dp(14);
            float y = ((H * (i * .19f) - now * dp(5 + i % 3 * 3)) % H + H) % H, r = dp(26 + i * 8);
            bp.setColor(alpha(ballCol[(i * 2) % 14], .07f)); c.drawCircle(x, y, r, bp);
        }
    }

    /* ======================= tap targets & input ======================= */
    void hit(RectF r, String act, int arg) {
        if (!hitsOn || hn >= MAXH) return;
        float t = r.top + hitOffY, b = r.bottom + hitOffY; if (b < clipT || t > clipB) return;
        hl[hn] = r.left; ht[hn] = Math.max(t, clipT); hr[hn] = r.right; hb[hn] = Math.min(b, clipB); ha[hn] = act; hg[hn] = arg; hn++;
    }
    int findHit(float x, float y) { for (int i = hn - 1; i >= 0; i--) if (x >= hl[i] && x <= hr[i] && y >= ht[i] && y <= hb[i]) return i; return -1; }
    float pressScale(String act, int arg) { return act.equals(pressAct) && arg == pressArg ? .95f : 1f; }
    boolean scrollable() { return dlg == D_NONE && (screen == LEVELS || screen == SHOP || screen == MISSIONS || screen == SETTINGS || screen == DAILY); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: { if (vt != null) vt.recycle(); vt = VelocityTracker.obtain(); vt.addMovement(e); scroller.forceFinished(true); downX = x; downY = lastY = y; dragging = false;
                int i = findHit(x, y); if (i >= 0) { pressAct = ha[i]; pressArg = hg[i]; } else pressAct = null; return true; }
            case MotionEvent.ACTION_MOVE: { if (vt != null) vt.addMovement(e);
                if (!dragging && scrollable() && Math.abs(y - downY) > slop) { dragging = true; pressAct = null; }
                if (dragging) { scrollY -= (y - lastY); clampScroll(); } lastY = y; return true; }
            case MotionEvent.ACTION_UP: {
                if (dragging && vt != null) { vt.addMovement(e); vt.computeCurrentVelocity(1000); float max = Math.max(0, contentH - (viewBottom - viewTop)); scroller.fling(0, (int) scrollY, 0, (int) -vt.getYVelocity(), 0, 0, 0, (int) max); }
                else if (pressAct != null) { int i = findHit(x, y); if (i >= 0 && ha[i].equals(pressAct) && hg[i] == pressArg) { String a = pressAct; int g = pressArg; pressAct = null; act(a, g); } }
                pressAct = null; dragging = false; if (vt != null) { vt.recycle(); vt = null; } return true; }
            case MotionEvent.ACTION_CANCEL: pressAct = null; dragging = false; return true;
        }
        return true;
    }

    /* ======================= navigation ======================= */
    void goTo(int s) {
        if (s == screen) return; screen = s; screenT = now; dlg = D_NONE; scrollY = 0; contentH = 0; scroller.forceFinished(true); fx.clear();
        host.ads().banner(s == LEVELS || s == SHOP || s == MISSIONS);
        if (s == LEVELS) centerLevels = true;                           // centre on current level at first draw
    }
    void openDialog(int k, String arg) { dlg = k; dlgArg = arg; dlgT = now; }
    void closeDialog() { dlg = D_NONE; }

    /** Android back button. Returns true when consumed. */
    public boolean onBack() {
        if (dlg != D_NONE) { if (dlg == D_WIN) act("next", 0); else if (dlg == D_PAUSE || dlg == D_OFFER || dlg == D_BRIEF || dlg == D_STUCK) closeDialog(); return true; }
        switch (screen) {
            case SPLASH: return true;
            case GAME: if (!over) openDialog(D_PAUSE, ""); else goTo(daily ? HOME : LEVELS); return true;
            case HOME: if (now - backT < 2f) return false; backT = now; toast("Press back again to exit"); return true;
            default: goTo(HOME); return true;
        }
    }
    float backT = -10;
    public void onAppPause() { appPausedAt = SystemClock.uptimeMillis() / 1000f; if (screen == GAME && !over && dlg == D_NONE && lvl != null && lvl.limitTime > 0) openDialog(D_PAUSE, ""); }
    public void onAppResume() { if (appPausedAt > 0) { gPaused += SystemClock.uptimeMillis() / 1000f - appPausedAt; appPausedAt = 0; } host.ads().banner(screen == LEVELS || screen == SHOP || screen == MISSIONS); }

    /* ======================= shared UI blocks ======================= */
    float header(Canvas c, String title, boolean coins) {
        float top = insetT + dp(10), bh = dp(46);
        rf.set(dp(16), top, dp(16) + bh, top + bh); float s = pressScale("back", 0); ui.roundIcon(c, rf, Ui.I_BACK, s, true); hit(rf, "back", 0);
        ui.textC(c, title, dp(16) + bh + dp(14), top + bh / 2, 24, Ui.TEXT, Ui.L, true);
        if (coins) { String cs = String.valueOf(P().coins); float w = ui.textW(cs, 16, true) + dp(52); rf.set(W - dp(16) - w, top + dp(3), W - dp(16), top + dp(43)); ui.chip(c, rf, cs, Ui.I_COIN, Ui.BRASS); }
        return top + bh + dp(12);
    }
    void tabs(Canvas c, String[] names, int sel, float y, String act) {
        float gap = dp(6), w = (W - dp(32) - gap * (names.length - 1)) / names.length, h = dp(40);
        for (int i = 0; i < names.length; i++) {
            float x = dp(16) + i * (w + gap); rf.set(x, y, x + w, y + h); boolean on = i == sel;
            c.save(); float s = pressScale(act, i); c.scale(s, s, rf.centerX(), rf.centerY());
            if (on) ui.vgrad(c, rf, dp(12), 0xFFF3C766, Ui.BRASS); else { ui.fill(c, rf, dp(12), Ui.PANEL); ui.stroke(c, rf, dp(12), Ui.LINE, dp(1)); }
            ui.textC(c, names[i], rf.centerX(), rf.centerY(), names[i].length() > 6 ? 12.5f : 14, on ? Ui.DARKTXT : Ui.MUT, Ui.C, true); c.restore(); hit(rf, act, i);
        }
    }
    void beginList(Canvas c, float top) { viewTop = top; viewBottom = H - insetB; c.save(); c.clipRect(0, viewTop, W, viewBottom); c.translate(0, -scrollY); clipT = viewTop; clipB = viewBottom; hitOffY = -scrollY; }
    void endList(Canvas c, float bottomY) { c.restore(); contentH = bottomY - viewTop + dp(24); hitOffY = 0; clipT = -1e9f; clipB = 1e9f; }
    void btn(Canvas c, RectF r, String label, boolean primary, boolean enabled, int icon, String act, int arg) {
        ui.button(c, r, label, primary, pressScale(act, arg), enabled, icon); if (enabled) hit(r, act, arg);
    }
    void badgeDot(Canvas c, float x, float y, String n) { float r = dp(11); ui.circle(c, x, y, r, Ui.BAD); ui.textC(c, n, x, y, 12, 0xFFFFFFFF, Ui.C, true); }

    void drawParticles(Canvas c) {
        for (int i = 0; i < fx.count; i++) { if (fx.life[i] <= 0) continue; float a = Fx.clamp01(fx.life[i] / fx.max[i] * 1.6f);
            bp.setColor(alpha(fx.color[i], a));
            if (fx.shape[i] == Fx.RECT) { c.save(); c.rotate(fx.rot[i] * 57.3f, fx.x[i], fx.y[i]); rf.set(fx.x[i] - fx.size[i], fx.y[i] - fx.size[i] * .5f, fx.x[i] + fx.size[i], fx.y[i] + fx.size[i] * .5f); c.drawRect(rf, bp); c.restore(); }
            else c.drawCircle(fx.x[i], fx.y[i], fx.size[i] * (fx.shape[i] == Fx.SPARK ? .6f + .4f * a : 1f), bp); }
    }
    void drawToast(Canvas c) {
        float age = now - toastT; if (age > 2.2f || toastMsg.isEmpty()) return; float a = Fx.clamp01(Math.min(age / .15f, (2.2f - age) / .3f));
        float w = Math.min(W - dp(40), ui.textW(toastMsg, 15, true) + dp(36)), y = H - insetB - dp(110) - (1 - a) * dp(-12);
        rf.set(W / 2f - w / 2, y, W / 2f + w / 2, y + dp(44)); ui.fill(c, rf, dp(22), alpha(0xFF05060F, .92f * a)); ui.stroke(c, rf, dp(22), alpha(Ui.LINE, a), dp(1));
        ui.textC(c, toastMsg, W / 2f, rf.centerY(), 15, alpha(Ui.TEXT, a), Ui.C, true);
    }

    /* ======================= ball + tube primitives ======================= */
    void drawBall(Canvas c, float x, float y, float r, int ci, float sx, float sy) {
        ci = ci % 14; c.save(); c.translate(x, y); c.scale(r * sx, r * sy); bp.setStyle(Paint.Style.FILL); bp.setShader(ballSh[ci]); c.drawCircle(0, 0, 1, bp); bp.setShader(null);
        bp.setColor(0x88FFFFFF); c.drawCircle(-.36f, -.42f, .2f, bp); c.restore();
        if (P().cb) ui.textC(c, String.valueOf(ci + 1), x, y, Math.max(9, r / d * .95f), 0xE6FFFFFF, Ui.C, true);
    }
    final float[] radii = new float[8];
    void tubePath(RectF r) { float rt = dp(7), rb = r.width() / 2; radii[0] = radii[1] = radii[2] = radii[3] = rt; radii[4] = radii[5] = radii[6] = radii[7] = rb; path.reset(); path.addRoundRect(r, radii, Path.Direction.CW); }
    int tubeIdx() { String t = P().tube; for (int i = 0; i < Catalog.TUBES.length; i++) if (Catalog.TUBES[i].equals(t)) return i; return 0; }
    void drawTubeShape(Canvas c, RectF r, int skin, float glow) {
        tubePath(r); bp.setShader(null); bp.setStyle(Paint.Style.FILL); bp.setColor(Catalog.TUBE_FILL[skin]); c.drawPath(path, bp);
        if (glow > 0) { for (int k = 3; k >= 1; k--) { bp.setStyle(Paint.Style.STROKE); bp.setStrokeWidth(dp(2 + k * 2.2f)); bp.setColor(alpha(Ui.BRASS, glow * .16f)); c.drawPath(path, bp); } }
        bp.setStyle(Paint.Style.STROKE); bp.setStrokeWidth(dp(1.8f)); bp.setColor(glow > 0 ? mix(Catalog.TUBE_EDGE[skin] | 0xFF000000, Ui.BRASS, glow) : Catalog.TUBE_EDGE[skin]); c.drawPath(path, bp);
        bp.setStyle(Paint.Style.FILL); bp.setColor(0x22FFFFFF); rf2.set(r.left + r.width() * .16f, r.top + dp(10), r.left + r.width() * .26f, r.bottom - r.width() * .55f); c.drawRoundRect(rf2, dp(3), dp(3), bp);
    }

    /* ======================= splash + home ======================= */
    void drawTitle(Canvas c, float cx, float base, float sp) {
        float sz = dp(sp), wC = ui.textW("C", sp, true), wL = ui.textW("lor", sp, true), bd = sz * .5f, total = wC + bd + dp(6) + wL, x0 = cx - total / 2;
        ui.text(c, "C", x0, base, sp, Ui.TEXT, Ui.L, true); drawBall(c, x0 + wC + dp(3) + bd / 2, base - sz * .27f, bd / 2, 0, 1, 1); ui.text(c, "lor", x0 + wC + bd + dp(6), base, sp, Ui.TEXT, Ui.L, true);
        ui.text(c, "Trap", cx - ui.textW("Trap", sp, true) / 2, base + sz * .92f, sp, Ui.TEXT, Ui.L, true);
    }
    void drawSplash(Canvas c) {
        float t = now - screenT, s = Fx.easeOutBack(t / .7f); c.save(); c.scale(.7f + .3f * s, .7f + .3f * s, W / 2f, H * .4f);
        drawTitle(c, W / 2f, H * .36f, 62); c.restore();
        rf.set(W * .3f, H * .62f, W * .7f, H * .62f + dp(8)); ui.bar(c, rf, t / 1.5f); ui.textC(c, "Think. Sort. Win.", W / 2f, H * .62f + dp(34), 15, Ui.MUT, Ui.C, false);
    }
    void drawHome(Canvas c) {
        Profile p = P(); Progress.ensurePeriods(p, today(), weekId());
        float top = insetT + dp(10), bh = dp(46); String cs = String.valueOf(p.coins); float cw = ui.textW(cs, 16, true) + dp(52);
        rf.set(dp(16), top + dp(3), dp(16) + cw, top + dp(43)); ui.chip(c, rf, cs, Ui.I_COIN, Ui.BRASS); hit(rf, "shop", 0);
        rf.set(W - dp(16) - bh, top, W - dp(16), top + bh); ui.roundIcon(c, rf, Ui.I_GEAR, pressScale("settings", 0), true); hit(rf, "settings", 0);
        drawTitle(c, W / 2f, insetT + H * .17f, 64);
        float bw = W - dp(32), by = H - insetB - dp(24) - dp(60);
        rf.set(dp(16), by, dp(16) + bw, by + dp(60)); btn(c, rf, p.unl > 1 ? "Continue · Level " + p.unl : "Play", true, true, Ui.I_PLAY, "play", 0);
        float py = by - dp(46); rf.set(dp(20), py, W - dp(20), py + dp(8)); ui.bar(c, rf, (p.unl - 1) / (float) Engine.LEVELS);
        ui.text(c, "Level " + p.unl + " of " + Engine.LEVELS, dp(20), py + dp(26), 13, Ui.MUT, Ui.L, false); ui.text(c, p.totalStars() + " of " + Engine.LEVELS * 3 + " stars", W - dp(20), py + dp(26), 13, Ui.MUT, Ui.R, false);
        float rh = dp(58), ry = py - dp(14) - rh, hw = (W - dp(42)) / 2; boolean dayReady = !today().equals(p.last);
        rf.set(dp(16), ry, dp(16) + hw, ry + rh); btn(c, rf, "Daily", false, true, Ui.I_CAL, "daily", 0); if (dayReady) ui.circle(c, rf.right - dp(10), rf.top + dp(10), dp(6), Ui.BAD);
        rf.set(dp(26) + hw, ry, dp(26) + 2 * hw, ry + rh); btn(c, rf, "Missions", false, true, Ui.I_MEDAL, "missions", 0); int pend = Progress.pending(p, today(), weekId()); if (pend > 0) badgeDot(c, rf.right - dp(8), rf.top + dp(4), String.valueOf(pend));
        float sy = ry - dp(12) - rh; rf.set(dp(16), sy, W - dp(16), sy + rh); btn(c, rf, "Shop", false, true, Ui.I_BAG, "shop", 0);
        // decorative bobbing tubes: scaled to whatever space is left between the title and the buttons
        float regionTop = insetT + H * .17f + dp(64) * .92f + dp(26), avail = sy - dp(18) - regionTop;
        if (avail > dp(95)) {
            float sc = Math.min(1f, avail / dp(160)), midY = regionTop + avail / 2, tw = dp(46), th = dp(150), gap = dp(16), x0 = W / 2f - (5 * tw + 4 * gap) / 2; int[][] deco = {{0, 1, 2, 3}, {4, 2, 5, 1}, {3, 6, 0, 4}, {5, 3, 1, 6}, {2, 0, 6, 5}};
            c.save(); c.scale(sc, sc, W / 2f, midY);
            for (int i = 0; i < 5; i++) {
                float x = x0 + i * (tw + gap), bob = P().rm ? 0 : (float) Math.sin(now * 1.4f + i * 1.1f) * dp(3), ty = midY - th / 2 + bob * .4f; rf.set(x, ty, x + tw, ty + th); drawTubeShape(c, rf, tubeIdx(), 0);
                for (int k = 0; k < 4; k++) drawBall(c, rf.centerX(), rf.bottom - dp(8) - dp(17.5f) - k * dp(33.6f), dp(15), deco[i][k], 1, 1);
            }
            c.restore();
        }
    }

    /* ======================= level roadmap ======================= */
    float nodeX(int i) { return W / 2f + (float) Math.sin(i * .82 + .4) * W * .27f; }
    void drawLevels(Canvas c) {
        float top = header(c, "Levels", false); String ss = String.valueOf(P().totalStars()); float sw = ui.textW(ss, 16, true) + dp(52); rf.set(W - dp(16) - sw, insetT + dp(13), W - dp(16), insetT + dp(53)); ui.chip(c, rf, ss, Ui.I_STAR, Ui.BRASS);
        viewTop = top; viewBottom = H - insetB; float SP = dp(94); int N = Engine.LEVELS, cur = Math.min(P().unl, N); contentH = (N - 1) * SP + dp(260);
        if (centerLevels) { centerLevels = false; scrollY = contentH - dp(130) - (cur - 1) * SP - (viewBottom - viewTop) * .6f; scroller.forceFinished(true); }
        clampScroll(); c.save(); c.clipRect(0, viewTop, W, viewBottom); c.translate(0, viewTop - scrollY); clipT = viewTop; clipB = viewBottom; hitOffY = viewTop - scrollY;
        float vis0 = scrollY - SP, vis1 = scrollY + (viewBottom - viewTop) + SP; bp.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 1; i < N; i++) {
            float y1 = contentH - dp(130) - (i - 1) * SP, y2 = y1 - SP; if (y1 < vis0 || y2 > vis1) continue; float x1 = nodeX(i), x2 = nodeX(i + 1);
            path.reset(); path.moveTo(x1, y1); path.cubicTo(x1, (y1 + y2) / 2, x2, (y1 + y2) / 2, x2, y2); bp.setStyle(Paint.Style.STROKE); bp.setStrokeWidth(dp(9)); bp.setColor(i < P().unl ? alpha(Ui.BRASS, .9f) : 0xFF1F2347); c.drawPath(path, bp);
        }
        bp.setStyle(Paint.Style.FILL);
        for (int i = 1; i <= N; i++) {
            float y = contentH - dp(130) - (i - 1) * SP; if (y < vis0 || y > vis1) continue; float x = nodeX(i); Engine.Level L = levels[i]; boolean locked = i > P().unl, isCur = i == P().unl; int stars = P().stars[i];
            float r = dp(i == cur ? 31 : 27); if (L != null && L.boss) r += dp(3);
            if (isCur) { float pr = r + dp(6) + (float) Math.sin(now * 4) * dp(3); bp.setColor(alpha(Ui.BRASS, .28f)); c.drawCircle(x, y, pr, bp); }
            rf.set(x - r, y - r, x + r, y + r); float sc = pressScale("lvl", i); c.save(); c.scale(sc, sc, x, y);
            if (locked) { ui.circle(c, x, y, r, 0xFF1C2044); bp.setStyle(Paint.Style.STROKE); bp.setStrokeWidth(dp(2)); bp.setColor(Ui.LINE); c.drawCircle(x, y, r, bp); bp.setStyle(Paint.Style.FILL); ui.icon(c, Ui.I_LOCK, x, y, dp(20), Ui.MUT); }
            else { ui.circle(c, x, y + dp(3), r, Ui.BRASS2); ui.circle(c, x, y, r, stars > 0 || isCur ? Ui.BRASS : 0xFF3A3F6E); ui.textC(c, String.valueOf(i), x, y - dp(stars > 0 ? 3 : 0), L != null && L.boss ? 19 : 20, stars > 0 || isCur ? Ui.DARKTXT : Ui.TEXT, Ui.C, true);
                for (int k = 0; k < stars; k++) ui.star(c, x + (k - (stars - 1) / 2f) * dp(10), y + r * .56f, dp(4.6f), Ui.DARKTXT, true); }
            c.restore();
            if (L != null && L.mods.length > 0) { int ic = L.boss ? Ui.I_CROWN : L.has("locked") ? Ui.I_LOCK : L.has("frozen") ? Ui.I_SNOW : L.has("time") ? Ui.I_TIMER : Ui.I_BAN; float bx = x + r * .78f, by2 = y - r * .78f; ui.circle(c, bx, by2, dp(11), locked ? 0xFF2A2F58 : Ui.PANEL); ui.icon(c, ic, bx, by2, dp(13), L.boss ? Ui.BRASS : Ui.TEXT); }
            rf.set(x - r, y - r, x + r, y + r); hit(rf, "lvl", i);
        }
        c.restore(); hitOffY = 0; clipT = -1e9f; clipB = 1e9f;
        rf.set(dp(16), H - insetB - dp(74), W - dp(16), H - insetB - dp(14)); btn(c, rf, "Play level " + cur, true, true, Ui.I_PLAY, "lvl", cur);
    }

    /* ======================= shop ======================= */
    int shopTab = 0; static final String[] SHOP_TABS = {"Balls", "Tubes", "Boards", "Boosts", "Free"};
    String[] shopNames() { return shopTab == 0 ? Catalog.THEMES : shopTab == 1 ? Catalog.TUBES : Catalog.BACKS; }
    String shopPrefix() { return shopTab == 0 ? "T:" : shopTab == 1 ? "U:" : "B:"; }
    int shopPrice(int i) { return shopTab == 0 ? Catalog.THEME_PRICE[i] : shopTab == 1 ? Catalog.TUBE_PRICE[i] : Catalog.BACK_PRICE[i]; }
    String shopHow(int i) { return shopTab == 1 ? Catalog.TUBE_HOW[i] : shopTab == 2 ? Catalog.BACK_HOW[i] : ""; }
    boolean shopInUse(int i) { String n = shopNames()[i], u = shopTab == 0 ? P().theme : shopTab == 1 ? P().tube : P().back; return n.equals(u); }
    static final String[] BOOST_NAME = {"Hints ×3", "Hints ×10", "Undos ×5", "Extra tubes ×3"}; static final int[] BOOST_PRICE = {100, 250, 80, 100};

    void drawShop(Canvas c) {
        float top = header(c, "Shop", true); tabs(c, SHOP_TABS, shopTab, top, "shoptab"); beginList(c, top + dp(52)); float y = viewTop + dp(6); Profile p = P();
        if (shopTab <= 2) {
            String[] names = shopNames(); float cw = (W - dp(42)) / 2, ch = dp(138);
            for (int i = 0; i < names.length; i++) {
                float x = dp(16) + (i % 2) * (cw + dp(10)), yy = y + (i / 2) * (ch + dp(10)); rf.set(x, yy, x + cw, yy + ch); boolean own = p.own.contains(shopPrefix() + names[i]), use = shopInUse(i);
                c.save(); float s = pressScale("shopitem", i); c.scale(s, s, rf.centerX(), rf.centerY()); ui.fill(c, rf, dp(16), use ? 0xFF3A3220 : Ui.PANEL); ui.stroke(c, rf, dp(16), use ? Ui.BRASS : Ui.LINE, dp(use ? 2 : 1));
                float cx = rf.centerX(), cy = yy + dp(48);
                if (shopTab == 0) for (int k = 0; k < 5; k++) drawMini(c, cx + (k - 2) * dp(20), cy, dp(8.5f), Catalog.THEME_COLORS[i][k]);
                else if (shopTab == 1) { rf2.set(cx - dp(16), yy + dp(12), cx + dp(16), yy + dp(82)); drawTubeShape(c, rf2, i, 0); drawMini(c, cx, yy + dp(70), dp(10), Catalog.THEME_COLORS[themeIdx][5]); drawMini(c, cx, yy + dp(48), dp(10), Catalog.THEME_COLORS[themeIdx][0]); }
                else { int[] bc = Catalog.BACK_COLORS[i]; rf2.set(cx - dp(46), yy + dp(14), cx + dp(46), yy + dp(80)); bp.setShader(new RadialGradient(cx, yy + dp(30), dp(80), bc[1], bc[0], Shader.TileMode.CLAMP)); c.drawRoundRect(rf2, dp(10), dp(10), bp); bp.setShader(null); }
                ui.text(c, names[i], cx, yy + dp(104), 15, Ui.TEXT, Ui.C, true);
                String sub = use ? "In use" : own ? "Owned" : shopPrice(i) < 0 ? shopHow(i) : shopPrice(i) + " coins"; ui.text(c, sub, cx, yy + dp(124), 12.5f, use ? Ui.BRASS : Ui.MUT, Ui.C, false);
                if (!own && shopPrice(i) < 0) ui.icon(c, Ui.I_LOCK, rf.right - dp(16), yy + dp(18), dp(15), Ui.MUT);
                c.restore(); rf.set(x, yy, x + cw, yy + ch); hit(rf, "shopitem", i);
            }
            y += ((names.length + 1) / 2) * (ch + dp(10));
        } else if (shopTab == 3) {
            for (int i = 0; i < 4; i++) { rf.set(dp(16), y, W - dp(16), y + dp(70)); ui.panel(c, rf); int have = i < 2 ? p.hints : i == 2 ? p.undos : p.tubes;
                ui.text(c, BOOST_NAME[i], dp(32), y + dp(30), 18, Ui.TEXT, Ui.L, true); ui.text(c, "You have " + have, dp(32), y + dp(54), 13, Ui.MUT, Ui.L, false);
                rf2.set(W - dp(130), y + dp(14), W - dp(28), y + dp(56)); btn(c, rf2, String.valueOf(BOOST_PRICE[i]), true, p.coins >= BOOST_PRICE[i], Ui.I_COIN, "boost", i); y += dp(80); }
        } else {
            Ads ads = host.ads(); y = freeRow(c, y, "Free coins", "+60 coins · " + ads.coinAdsLeft(today()) + " left today", "freecoins", ads.rewardedReady() && ads.coinAdsLeft(today()) > 0);
            y = freeRow(c, y, "Free hint", "+1 hint · you have " + p.hints, "freehint", ads.rewardedReady());
            rf.set(dp(16), y, W - dp(16), y + dp(64)); ui.panel(c, rf); ui.wrap(c, ads.enabled() ? "Videos are always optional and never shown during a puzzle." : "Videos are unavailable right now (offline, not consented, or still loading).", dp(32), y + dp(26), W - dp(64), 13.5f, Ui.MUT, Ui.L, dp(19)); y += dp(74);
        }
        endList(c, y);
    }
    float freeRow(Canvas c, float y, String title, String sub, String act, boolean ok) {
        rf.set(dp(16), y, W - dp(16), y + dp(76)); ui.panel(c, rf); ui.text(c, title, dp(32), y + dp(32), 18, Ui.TEXT, Ui.L, true); ui.text(c, sub, dp(32), y + dp(56), 12.5f, Ui.MUT, Ui.L, false);
        rf2.set(W - dp(136), y + dp(16), W - dp(28), y + dp(60)); btn(c, rf2, host.ads().loading() ? "Loading" : "Watch", true, ok, Ui.I_VIDEO, act, 0); return y + dp(86);
    }
    final java.util.HashMap<Integer, Shader> miniSh = new java.util.HashMap<>();
    void drawMini(Canvas c, float x, float y, float r, int col) {
        Shader sh = miniSh.get(col); if (sh == null) { sh = new RadialGradient(-.3f, -.35f, 1.45f, new int[]{mix(col, 0xFFFFFFFF, .6f), col, mix(col, 0xFF000000, .5f)}, new float[]{0, .5f, 1}, Shader.TileMode.CLAMP); miniSh.put(col, sh); }
        c.save(); c.translate(x, y); c.scale(r, r); bp.setStyle(Paint.Style.FILL); bp.setShader(sh); c.drawCircle(0, 0, 1, bp); bp.setShader(null); c.restore();
    }

    /* ======================= missions / badges / rewards ======================= */
    int missTab = 0; static final String[] MISS_TABS = {"Daily", "Weekly", "Badges", "Rewards"};
    void drawMissions(Canvas c) {
        Profile p = P(); Progress.ensurePeriods(p, today(), weekId()); float top = header(c, "Missions", true); tabs(c, MISS_TABS, missTab, top, "misstab"); beginList(c, top + dp(52)); float y = viewTop + dp(6);
        if (missTab <= 1) {
            Progress.Quest[] qs = missTab == 0 ? Progress.dailyMissions(today()) : Progress.WEEKLY; java.util.Map<String, Integer> pr = missTab == 0 ? p.dmP : p.wkP, cl = missTab == 0 ? p.dmC : p.wkC;
            ui.text(c, missTab == 0 ? "New missions every day" : "Resets every Monday", dp(20), y + dp(16), 13.5f, Ui.MUT, Ui.L, false); y += dp(28);
            for (int i = 0; i < qs.length; i++) { Progress.Quest q = qs[i]; int g = Progress.prog(pr, q); boolean done = g >= q.goal, claimed = cl.containsKey(q.id); String extra = (q.hints > 0 ? " · +" + q.hints + " hints" : "") + (q.tubes > 0 ? " · +" + q.tubes + " tubes" : "");
                y = questRow(c, y, q.title, g, q.goal, g + "/" + q.goal + extra, claimed ? "Claimed" : done ? "+" + q.coins : q.coins + "", done && !claimed, "claimq", i); }
        } else if (missTab == 2) {
            for (int i = 0; i < Progress.BADGES.length; i++) { Progress.Badge b = Progress.BADGES[i]; Integer s = p.ach.get(b.id); int st = s == null ? 0 : s; rf.set(dp(16), y, W - dp(16), y + dp(74)); ui.panel(c, rf);
                ui.circle(c, dp(52), y + dp(37), dp(20), st > 0 ? Ui.BRASS : 0xFF1C2044); ui.icon(c, st > 0 ? Ui.I_MEDAL : Ui.I_LOCK, dp(52), y + dp(37), dp(22), st > 0 ? Ui.DARKTXT : Ui.MUT);
                ui.text(c, b.title, dp(84), y + dp(32), 16.5f, st > 0 ? Ui.TEXT : Ui.MUT, Ui.L, true); ui.text(c, b.desc, dp(84), y + dp(54), 12.5f, Ui.MUT, Ui.L, false);
                rf2.set(W - dp(124), y + dp(17), W - dp(28), y + dp(57)); btn(c, rf2, st == 2 ? "Claimed" : st == 1 ? "+" + b.coins : b.coins + "", st == 1, st == 1, -1, "claimb", i); y += dp(84); }
        } else {
            ui.text(c, "Rewards for clearing levels and collecting stars", dp(20), y + dp(16), 13.5f, Ui.MUT, Ui.L, false); y += dp(28);
            for (int i = 0; i < Progress.MILESTONES.length; i++) { Progress.Milestone m = Progress.MILESTONES[i]; int v = Progress.value(p, m); boolean ok = v >= m.at, cl = p.ms.containsKey(m.id);
                y = questRow(c, y, m.at + (m.byLevels ? " levels cleared" : " stars"), Math.min(v, m.at), m.at, Math.min(v, m.at) + "/" + m.at + " · " + m.coins + " coins · " + m.title, cl ? "Claimed" : ok ? "Claim" : "Locked", ok && !cl, "claimm", i); }
        }
        endList(c, y);
    }
    float questRow(Canvas c, float y, String title, int val, int goal, String sub, String btnLabel, boolean enabled, String act, int arg) {
        rf.set(dp(16), y, W - dp(16), y + dp(82)); ui.panel(c, rf); ui.text(c, title, dp(32), y + dp(28), 16.5f, Ui.TEXT, Ui.L, true);
        rf2.set(dp(32), y + dp(40), W - dp(150), y + dp(48)); ui.bar(c, rf2, goal == 0 ? 0 : val / (float) goal); ui.text(c, sub, dp(32), y + dp(68), 12.5f, Ui.MUT, Ui.L, false);
        rf2.set(W - dp(126), y + dp(21), W - dp(28), y + dp(61)); btn(c, rf2, btnLabel, enabled, enabled, -1, act, arg); return y + dp(92);
    }

    /* ======================= settings ======================= */
    long resetArm;
    void drawSettings(Canvas c) {
        Profile p = P(); float top = header(c, "Settings", false); beginList(c, top); float y = viewTop + dp(6);
        String[] names = {"Sound effects", "Haptics", "Number marks", "Reduce motion"}, subs = {"Glass clinks, chimes and fanfares", "Vibrate on moves", "A number on each ball (colour-blind)", "Calmer animations"};
        boolean[] on = {p.snd, p.vib, p.cb, p.rm};
        for (int i = 0; i < 4; i++) { rf.set(dp(16), y, W - dp(16), y + dp(70)); ui.panel(c, rf); ui.text(c, names[i], dp(32), y + dp(30), 17, Ui.TEXT, Ui.L, true); ui.text(c, subs[i], dp(32), y + dp(52), 12.5f, Ui.MUT, Ui.L, false);
            float sx = W - dp(76), sy = y + dp(35); rf2.set(sx, sy - dp(14), sx + dp(48), sy + dp(14)); ui.fill(c, rf2, dp(14), on[i] ? Ui.BRASS : 0xFF11132A); ui.circle(c, on[i] ? sx + dp(34) : sx + dp(14), sy, dp(10), on[i] ? Ui.DARKTXT : Ui.MUT);
            rf2.set(dp(16), y, W - dp(16), y + dp(70)); hit(rf2, "toggle", i); y += dp(80); }
        rf.set(dp(16), y, W - dp(16), y + dp(64)); ui.panel(c, rf); ui.wrap(c, "Tip: the free Accessible ball theme (Shop → Balls) uses a colour-blind-safe palette.", dp(32), y + dp(26), W - dp(64), 13.5f, Ui.MUT, Ui.L, dp(19)); y += dp(78);
        if (host.ads().privacyRequired) { rf.set(dp(16), y, W - dp(16), y + dp(56)); btn(c, rf, "Privacy & ad choices", false, true, -1, "privacy", 0); y += dp(68); }
        boolean armed = now * 1000 - resetArm < 3000 && resetArm > 0; rf.set(dp(16), y, W - dp(16), y + dp(56)); btn(c, rf, armed ? "Tap again to erase everything" : "Reset progress", false, true, -1, "reset", 0); y += dp(70);
        ui.text(c, "Color Trap v" + VERSION + " · " + (host.profile() != null ? "progress saved on this device" : ""), W / 2f, y + dp(10), 12.5f, Ui.MUT, Ui.C, false); endList(c, y + dp(20));
    }

    /* ======================= daily ======================= */
    static final int[] DAILY_RW = {50, 60, 70, 80, 100, 120, 150};
    void drawDaily(Canvas c) {
        Profile p = P(); float top = header(c, "Daily", true); boolean ready = !today().equals(p.last), done = today().equals(p.daily); beginList(c, top); float y = viewTop + dp(6);
        rf.set(dp(16), y, W - dp(16), y + dp(250)); ui.panel(c, rf); ui.text(c, "Login streak", dp(32), y + dp(36), 20, Ui.TEXT, Ui.L, true); ui.text(c, "Come back each day for a bigger reward.", dp(32), y + dp(58), 13, Ui.MUT, Ui.L, false);
        float gw = (W - dp(32) - dp(32) - dp(6) * 6) / 7;
        for (int i = 0; i < 7; i++) { float x = dp(32) + i * (gw + dp(6)); rf2.set(x, y + dp(76), x + gw, y + dp(76) + dp(78)); boolean cur = i == p.day, past = i < p.day;
            ui.fill(c, rf2, dp(12), cur ? 0xFF3A3220 : Ui.PANEL2); ui.stroke(c, rf2, dp(12), cur ? Ui.BRASS : Ui.LINE, dp(cur ? 2 : 1)); ui.text(c, "Day", rf2.centerX(), y + dp(98), 10.5f, Ui.MUT, Ui.C, false); ui.text(c, String.valueOf(i + 1), rf2.centerX(), y + dp(120), 17, Ui.TEXT, Ui.C, true);
            if (past) ui.star(c, rf2.centerX(), y + dp(139), dp(7), Ui.BRASS, true); else ui.text(c, "+" + DAILY_RW[i], rf2.centerX(), y + dp(143), 10.5f, cur ? Ui.BRASS : Ui.MUT, Ui.C, true); }
        rf2.set(dp(32), y + dp(172), W - dp(32), y + dp(228)); btn(c, rf2, ready ? "Claim " + DAILY_RW[p.day] + " coins" : "Come back tomorrow", true, ready, -1, "claimday", 0); y += dp(266);
        rf.set(dp(16), y, W - dp(16), y + dp(176)); ui.panel(c, rf); ui.text(c, "Today's puzzle", dp(32), y + dp(36), 20, Ui.TEXT, Ui.L, true);
        Calendar n = Calendar.getInstance(); int mins = (23 - n.get(Calendar.HOUR_OF_DAY)) * 60 + (59 - n.get(Calendar.MINUTE)); ui.text(c, "New puzzle in " + mins / 60 + "h " + mins % 60 + "m · reward 100 coins", dp(32), y + dp(58), 13, Ui.MUT, Ui.L, false);
        rf2.set(dp(32), y + dp(88), W - dp(32), y + dp(144)); btn(c, rf2, done ? "Completed today" : "Play", true, !done, done ? Ui.I_CHECK : Ui.I_PLAY, "playdaily", 0); y += dp(196); endList(c, y);
    }

    /* ======================= gameplay state ======================= */
    Engine.Level lvl; int levelNo; boolean daily; Engine.State gs; int sel = -1; boolean over, extraUsed, hinted; int uf = 6, tubesDone, bonusMoves; float gStart, gPaused, bonusT; int tut = -1;
    static final class Snap { Engine.Board T; int moves; boolean unl; int hist; }
    static final class Flight { int color, dest; float x0, y0, x1, y1, cx0, cy0, cx1, cy1, t0, dur; }
    final ArrayList<Snap> undo = new ArrayList<>(); final ArrayList<int[]> hist = new ArrayList<>(); final ArrayList<Flight> flights = new ArrayList<>();
    static final int MT = 20; final Fx.Spring[] lift = new Fx.Spring[MT]; final float[] landT = new float[MT], popT = new float[MT], shakeT = new float[MT]; final int[] hide = new int[MT]; final boolean[] wasDone = new boolean[MT]; final RectF[] tr = new RectF[MT];
    float ballR, slot, padB, hintUntil, endAt, lastTap; int hintA = -1, hintB = -1, endKind;
    int winStars, winMoves; Progress.Reward winRw;
    { for (int i = 0; i < MT; i++) { lift[i] = new Fx.Spring(0); tr[i] = new RectF(); } }

    void initGame() {
        sel = -1; over = false; extraUsed = false; hinted = false; uf = 6; tubesDone = 0; undo.clear(); hist.clear(); flights.clear(); gStart = now; gPaused = 0; bonusT = 0; bonusMoves = 0; tut = -1; endKind = 0; hintUntil = 0;
        for (int i = 0; i < MT; i++) { lift[i].x = lift[i].v = lift[i].target = 0; landT[i] = popT[i] = shakeT[i] = -10; hide[i] = 0; wasDone[i] = false; }
    }
    void startLevel(int n) {
        lvl = levels[n]; levelNo = n; daily = false; gs = lvl.newState(); initGame(); if (n == 1 && P().tut == 0 && lvl.sol.length > 3) tut = 0;
        Progress.event(P(), "played", 1, today(), weekId()); if (screen != GAME) goTo(GAME); else screenT = now; dlg = D_NONE; host.ads().banner(false);
    }
    void startDaily() { lvl = null; levelNo = 0; daily = true; gs = new Engine.State(); gs.T = Engine.dailyBoard(today()); initGame(); if (screen != GAME) goTo(GAME); else screenT = now; dlg = D_NONE; }
    int limitMoves() { return lvl == null || lvl.limitMoves == 0 ? 0 : lvl.limitMoves + bonusMoves; }
    float timeLeft() { return lvl == null || lvl.limitTime == 0 ? -1 : lvl.limitTime + bonusT - (now - gStart - gPaused); }

    void updateGame() {
        if (gs == null) return;
        if (dlg != D_NONE && appPausedAt == 0) gPaused += dt;
        for (int i = 0; i < gs.T.n; i++) { lift[i].target = (sel == i && !over) ? 1 : 0; lift[i].step(dt); if (!gs.T.full(i)) wasDone[i] = false; }
        for (int k = flights.size() - 1; k >= 0; k--) { Flight f = flights.get(k); if (now >= f.t0 + f.dur) { flights.remove(k); land(f); } }
        if (!over && dlg == D_NONE && lvl != null && lvl.limitTime > 0 && timeLeft() <= 0) { over = true; endKind = 3; endAt = now + .25f; }
        if (endKind != 0 && now >= endAt && flights.isEmpty()) { int k = endKind; endKind = 0; if (k == 1) finishWin(); else if (k == 2) { sfx(Sfx.LOSE); vib(60); openDialog(D_FAIL, "moves"); } else if (k == 3) { sfx(Sfx.LOSE); vib(60); openDialog(D_FAIL, "time"); } else if (k == 4 && !over) { sfx(Sfx.BAD); openDialog(D_STUCK, ""); } }
    }
    void land(Flight f) {
        int i = f.dest; hide[i] = Math.max(0, hide[i] - 1); landT[i] = now; sfx(Sfx.DROP); fx.burst(f.x1, f.y1 + ballR * .4f, 5, mix(ballCol[f.color], 0xFFFFFFFF, .4f), dp(70), dp(2.2f));
        if (hide[i] == 0 && gs.T.full(i) && !wasDone[i]) { wasDone[i] = true; popT[i] = now; tubesDone++; sfx(Sfx.DONE); vib(20); fx.burst(tr[i].centerX(), tr[i].top, 22, Ui.BRASS, dp(180), dp(3)); fx.burst(tr[i].centerX(), tr[i].top, 10, 0xFFFFFFFF, dp(120), dp(2)); }
    }

    /* ---- layout ---- */
    void layoutTubes(float bt, float bb) {
        int n = gs.T.n, rows = n <= 5 ? 1 : n <= 12 ? 2 : 3, cols = (n + rows - 1) / rows; float gapX = dp(12), gapY = dp(16), availW = W - dp(32), availH = bb - bt;
        float bw = (availW - (cols - 1) * gapX) / cols - dp(14), bh = (availH - (rows - 1) * gapY - rows * dp(16) - dp(34)) / (rows * 4.24f + 1.0f);
        ballR = Math.max(dp(8), Math.min(Math.min(bw, bh), dp(46)) / 2); slot = ballR * 2 * 1.06f; padB = dp(8) + ballR * .0f;
        float tw = ballR * 2 + dp(14), th = slot * 4 + dp(16), rowH = th + gapY, totalH = rows * th + (rows - 1) * gapY, y0 = bt + Math.max(dp(18) + ballR * 2, (availH - totalH) / 2 + ballR * .8f);
        for (int r = 0; r < rows; r++) { int inRow = Math.min(cols, n - r * cols); float rowW = inRow * tw + (inRow - 1) * gapX, x0 = (W - rowW) / 2;
            for (int k = 0; k < inRow; k++) { int i = r * cols + k; float x = x0 + k * (tw + gapX), y = y0 + r * rowH; tr[i].set(x, y, x + tw, y + th); } }
    }
    float slotY(int i, int k) { return tr[i].bottom - dp(8) - slot * (k + .5f); }
    float liftedY(int i) { return tr[i].top - ballR * .75f; }

    /* ---- drawing ---- */
    void drawGame(Canvas c) {
        if (gs == null) { goTo(HOME); return; }
        float top = insetT + dp(10), bh = dp(46); rf.set(dp(16), top, dp(16) + bh, top + bh); ui.roundIcon(c, rf, Ui.I_PAUSE, pressScale("pause", 0), true); hit(rf, "pause", 0);
        String title = daily ? "Daily puzzle" : (lvl.boss ? "Boss · Level " : "Level ") + levelNo; ui.text(c, title, dp(16) + bh + dp(14), top + dp(21), 22, Ui.TEXT, Ui.L, true); ui.text(c, (daily ? 4 : lvl.c) + " colors", dp(16) + bh + dp(14), top + dp(42), 13, Ui.MUT, Ui.L, false);
        String lab = "Moves", val = String.valueOf(gs.moves); int vcol = Ui.TEXT; float tl = timeLeft();
        if (tl >= 0) { lab = "Time"; int s = (int) Math.ceil(Math.max(0, tl)); val = (s / 60) + ":" + String.format(Locale.US, "%02d", s % 60); if (tl < 10) vcol = Ui.BAD; }
        else if (limitMoves() > 0) { lab = "Moves left"; int left = Math.max(0, limitMoves() - gs.moves); val = String.valueOf(left); if (left <= 3) vcol = Ui.BAD; }
        ui.text(c, lab, W - dp(18), top + dp(16), 13, Ui.MUT, Ui.R, false); ui.text(c, val, W - dp(18), top + dp(46), 32, vcol, Ui.R, true);
        float y = top + bh + dp(12); y = drawRules(c, y); y = drawCoach(c, y);
        float btnTop = H - insetB - dp(98); layoutTubes(y + dp(6), btnTop - dp(8)); drawTubes(c); drawBottom(c, btnTop);
    }
    float drawRules(Canvas c, float y) {
        ArrayList<String> chips = new ArrayList<>(); ArrayList<Integer> ics = new ArrayList<>();
        if (gs.lock.length > 0) { chips.add(gs.unl ? "Locks open" : "Locked · complete a tube"); ics.add(Ui.I_LOCK); }
        if (lvl != null && lvl.has("frozen")) { chips.add("Frozen tubes"); ics.add(Ui.I_SNOW); }
        if (limitMoves() > 0) { chips.add(gs.moves + "/" + limitMoves() + " moves"); ics.add(Ui.I_BAN); }
        if (lvl != null && lvl.has("noundo")) { chips.add("No undo"); ics.add(Ui.I_BAN); }
        if (lvl != null && lvl.has("nohint")) { chips.add("No hints"); ics.add(Ui.I_BAN); }
        if (chips.isEmpty()) return y; float tot = 0; for (String s : chips) tot += ui.textW(s, 12, true) + dp(38); tot += (chips.size() - 1) * dp(6); float x = (W - tot) / 2, h = dp(28);
        for (int i = 0; i < chips.size(); i++) { float w = ui.textW(chips.get(i), 12, true) + dp(38); rf.set(x, y, x + w, y + h); ui.fill(c, rf, h / 2, Ui.PANEL); ui.stroke(c, rf, h / 2, Ui.LINE, dp(1)); ui.icon(c, ics.get(i), x + dp(14), y + h / 2, dp(13), Ui.BRASS); ui.textC(c, chips.get(i), x + dp(26), y + h / 2, 12, Ui.TEXT, Ui.L, true); x += w + dp(6); }
        return y + h + dp(6);
    }
    static final String[] TUT = {"Tap a tube to lift its top ball.", "Now tap the glowing tube. Balls pour onto the same colour, or into an empty tube.", "Nice! Lift another ball.", "Pour it onto the glowing tube."};
    float drawCoach(Canvas c, float y) {
        if (tut < 0) return y; rf.set(dp(16), y, W - dp(16), y + dp(54)); ui.fill(c, rf, dp(14), 0x33E8B04B); ui.stroke(c, rf, dp(14), Ui.BRASS, dp(1.2f));
        ui.wrap(c, TUT[tut], dp(30), y + dp(22), W - dp(120), 13.5f, Ui.TEXT, Ui.L, dp(18)); rf2.set(W - dp(86), y + dp(8), W - dp(22), y + dp(46)); ui.text(c, "Skip", rf2.centerX(), rf2.centerY() + dp(5), 14, Ui.BRASS, Ui.C, true); hit(rf2, "skiptut", 0); return y + dp(62);
    }
    void drawTubes(Canvas c) {
        Engine.Board T = gs.T; int skin = tubeIdx();
        for (int i = 0; i < T.n; i++) {
            RectF r = tr[i]; float pa = Fx.clamp01((now - popT[i]) / .5f), pop = pa < 1 ? (float) Math.sin(pa * Math.PI) * .07f : 0, sh = Fx.clamp01((now - shakeT[i]) / .35f), dx = sh < 1 ? (float) Math.sin(sh * 38) * (1 - sh) * dp(6) : 0;
            boolean done = T.full(i) && hide[i] == 0, locked = Engine.isLocked(gs, i); int fz = Engine.frozenLeft(gs, i);
            c.save(); c.translate(dx, 0); c.scale(1 + pop, 1 + pop, r.centerX(), r.bottom);
            float glow = done ? .55f + .2f * (float) Math.sin(now * 3) : Fx.clamp01(lift[i].x) * .9f; drawTubeShape(c, r, skin, glow);
            int nv = T.len[i] - hide[i];
            for (int k = 0; k < nv; k++) { float y = slotY(i, k), sx = 1, sy = 1;
                if (k == nv - 1) { if (sel == i) y = Fx.lerp(y, liftedY(i), lift[i].x); else if (lift[i].x > .01f) y = Fx.lerp(y, liftedY(i), lift[i].x); float lt = now - landT[i]; if (lt < .5f && !P().rm) { float a = (float) (Math.exp(-lt * 9) * Math.sin(lt * 30)); sx = 1 - .18f * a; sy = 1 + .26f * a; } }
                drawBall(c, r.centerX(), y, ballR, T.b[i][k], sx, sy); }
            if (locked) { rf2.set(r); ui.fill(c, rf2, dp(14), 0xB0070816); ui.icon(c, Ui.I_LOCK, r.centerX(), r.centerY(), dp(26), 0xFFE9E4D6); }
            else if (fz > 0) { rf2.set(r); ui.fill(c, rf2, dp(14), 0x5594DFFF); float shim = (now * .6f + i * .3f) % 1f; bp.setColor(0x33FFFFFF); c.drawRect(r.left, r.top + (r.height() * shim), r.right, r.top + r.height() * shim + dp(5), bp); ui.icon(c, Ui.I_SNOW, r.centerX(), r.centerY() - dp(10), dp(26), 0xFFFFFFFF); ui.textC(c, String.valueOf(fz), r.centerX(), r.centerY() + dp(16), 16, 0xFFFFFFFF, Ui.C, true); }
            c.restore();
            boolean hinted = now < hintUntil && (i == hintA || i == hintB), tutH = tut >= 0 && sel != tutNeedOrNone() && i == tutNeedOrNone();
            if (hinted || tutH) { float pu = .5f + .5f * (float) Math.sin(now * 7); rf2.set(r.left - dp(4), r.top - dp(4), r.right + dp(4), r.bottom + dp(4)); ui.stroke(c, rf2, dp(20), alpha(Ui.BRASS, .4f + .6f * pu), dp(3)); }
            rf2.set(r.left - dp(5), r.top - ballR * 1.5f, r.right + dp(5), r.bottom + dp(4)); hit(rf2, "tube", i);
        }
        for (Flight f : flights) {
            float u = Fx.clamp01((now - f.t0) / f.dur), t = Fx.easeInOutCubic(u), x = Fx.bez(f.x0, f.cx0, f.cx1, f.x1, t), y = Fx.bez(f.y0, f.cy0, f.cy1, f.y1, t), s = (float) Math.sin(u * Math.PI);
            if (now >= f.t0 && !P().rm && u < .9f) fx.emit(x, y, 0, 0, .25f, ballR * .35f, alpha(ballCol[f.color], .6f), Fx.CIRCLE);
            drawBall(c, x, y, ballR, f.color, 1 - .1f * s, 1 + .14f * s);
        }
    }
    int tutNeedOrNone() { if (tut < 0 || lvl == null || lvl.sol.length < 2) return -1; int[] m = lvl.sol[tut >> 1]; return tut % 2 == 0 ? m[0] : m[1]; }
    void drawBottom(Canvas c, float y) {
        String[] lab = {"Undo", "Hint", "Extra tube", "Restart"}; int[] ic = {Ui.I_UNDO, Ui.I_BULB, Ui.I_PLUS, Ui.I_RESTART}; String[] act = {"undo", "hint", "extra", "restart"};
        boolean noU = lvl != null && lvl.has("noundo"), noH = lvl != null && lvl.has("nohint"); int[] cnt = {noU ? -1 : uf + P().undos, noH ? -1 : P().hints, P().tubes, -1}; boolean[] en = {!noU, !noH, true, true};
        float bw = dp(58), gap = (W - dp(32) - bw * 4) / 3;
        for (int i = 0; i < 4; i++) { float x = dp(16) + i * (bw + gap); rf.set(x, y, x + bw, y + bw); ui.roundIcon(c, rf, ic[i], pressScale(act[i], 0), en[i]); hit(rf, act[i], 0);
            ui.text(c, lab[i], rf.centerX(), y + bw + dp(16), 12, en[i] ? Ui.TEXT : Ui.MUT, Ui.C, true); if (cnt[i] >= 0) { ui.circle(c, rf.right - dp(2), rf.top + dp(2), dp(11), Ui.BRASS); ui.textC(c, String.valueOf(Math.min(cnt[i], 99)), rf.right - dp(2), rf.top + dp(2), 12, Ui.DARKTXT, Ui.C, true); } }
    }

    /* ---- interaction ---- */
    void tapTube(int i) {
        if (over || gs == null || i >= gs.T.n) return; if (!flights.isEmpty()) return; if (now - lastTap < .11f) return; lastTap = now;
        if (tut >= 0 && !tutAllows(i)) { sfx(Sfx.BAD); toast("Follow the glowing tube"); return; }
        if (Engine.sealed(gs, i)) { sfx(Sfx.BAD); shakeT[i] = now; vib(25); toast(Engine.isLocked(gs, i) ? "Locked — complete a tube to open it" : "Frozen — thaws in " + Engine.frozenLeft(gs, i) + " moves"); return; }
        if (sel < 0) { if (gs.T.len[i] > 0) { sel = i; sfx(Sfx.SEL); vib(8); tutAdvance(true); } return; }
        if (sel == i) { sel = -1; sfx(Sfx.CLICK); return; }
        int n = Engine.pourN(gs, sel, i);
        if (n == 0) { sfx(Sfx.BAD); shakeT[i] = now; vib(20); sel = gs.T.len[i] > 0 ? i : -1; return; }
        pour(sel, i, n);
    }
    void pour(int from, int to, int n) {
        Engine.Board T = gs.T; int len0 = T.len[from], len1 = T.len[to]; boolean wasUnl = gs.unl; int[] fzBefore = new int[T.n]; for (int k = 0; k < T.n; k++) fzBefore[k] = Engine.frozenLeft(gs, k);
        Snap s = new Snap(); s.T = T.copy(); s.moves = gs.moves; s.unl = gs.unl; s.hist = hist.size(); undo.add(s);
        float cxTo = tr[to].centerX(), cxFrom = tr[from].centerX(); float apex = Math.min(liftedY(from), liftedY(to)) - ballR * .9f;
        for (int k = 0; k < n; k++) {
            Flight f = new Flight(); f.color = T.b[from][len0 - 1 - k]; f.dest = to; f.x0 = cxFrom; f.y0 = k == 0 ? Fx.lerp(slotY(from, len0 - 1), liftedY(from), Fx.clamp01(lift[from].x)) : slotY(from, len0 - 1 - k);
            f.x1 = cxTo; f.y1 = slotY(to, len1 + k); f.cx0 = cxFrom; f.cy0 = apex; f.cx1 = cxTo; f.cy1 = apex; float dist = Math.abs(cxTo - cxFrom);
            f.t0 = now + k * .075f; f.dur = (.40f + dist / d * .0006f) * (P().rm ? .35f : 1f); flights.add(f);
        }
        hide[to] += n; Engine.doPour(gs, from, to); hist.add(new int[]{from, to}); sel = -1; sfx(Sfx.POUR); vib(12);
        if (!wasUnl && gs.unl && gs.lock.length > 0) { sfx(Sfx.UNLOCK); toast("Locked tubes opened!"); fx.burst(W / 2f, H * .4f, 24, 0xFFFFFFFF, dp(160), dp(3)); }
        for (int k = 0; k < T.n; k++) if (fzBefore[k] > 0 && Engine.frozenLeft(gs, k) == 0) { sfx(Sfx.UNLOCK); toast("Frozen tube thawed"); fx.burst(tr[k].centerX(), tr[k].centerY(), 26, 0xFF9FE3FF, dp(170), dp(3)); }
        tutAdvance(false);
        if (Engine.isWon(gs.T)) { over = true; endKind = 1; endAt = now + .9f; return; }
        if (limitMoves() > 0 && gs.moves >= limitMoves()) { over = true; endKind = 2; endAt = now + .9f; return; }
        if (!Engine.anyMove(gs)) { endKind = 4; endAt = now + .9f; }
    }
    void doUndo() {
        if (over || !flights.isEmpty()) return; if (lvl != null && lvl.has("noundo")) { toast("No undo on this challenge"); return; } if (undo.isEmpty()) { toast("Nothing to undo"); return; }
        if (uf < 1 && P().undos < 1) { openDialog(D_OFFER, "undo"); return; }
        if (uf > 0) uf--; else { P().undos--; host.save(); }
        Snap s = undo.remove(undo.size() - 1); int had = gs.T.n; gs.T = s.T.copy(); while (gs.T.n < had) gs.T.addTube(); gs.moves = s.moves; gs.unl = s.unl; while (hist.size() > s.hist) hist.remove(hist.size() - 1);
        sel = -1; for (int i = 0; i < MT; i++) hide[i] = 0; sfx(Sfx.CLICK); endKind = 0;
    }
    void doHint() {
        if (over) return; if (lvl != null && lvl.has("nohint")) { toast("No hints on this challenge"); return; } if (tut >= 0) { toast("Follow the glowing tube"); return; }
        if (P().hints < 1) { openDialog(D_OFFER, "hint"); return; }
        int[] m = null; boolean follow = lvl != null && lvl.sol.length > hist.size();
        if (follow) for (int k = 0; k < hist.size() && follow; k++) if (hist.get(k)[0] != lvl.sol[k][0] || hist.get(k)[1] != lvl.sol[k][1]) follow = false;
        m = follow ? lvl.sol[hist.size()] : Engine.hintMove(gs);
        if (m == null) { toast("No good move — try Undo"); return; }
        P().hints--; hinted = true; host.save(); sel = -1; hintA = m[0]; hintB = m[1]; hintUntil = now + 2f; sfx(Sfx.SEL);
    }
    void doExtra() { if (over) return; if (extraUsed) { toast("One extra tube per level"); return; } if (P().tubes < 1) { toast("No extra tubes — get more in the Shop"); return; } if (gs.T.n >= MT - 1) return; P().tubes--; extraUsed = true; gs.T.addTube(); host.save(); sfx(Sfx.CLICK); }

    /* ---- tutorial ---- */
    boolean tutAllows(int i) { int need = tutNeedOrNone(); return i == need || (tut % 2 == 1 && (i == sel || (sel < 0 && i == lvl.sol[tut >> 1][0]))); }
    void tutAdvance(boolean selected) {
        if (tut < 0) return; if ((tut % 2 == 0 && selected) || (tut % 2 == 1 && !selected)) tut++;
        if (tut >= 4) { tut = -1; P().tut = 1; host.save(); toast("Great! Fill every tube with one colour."); }
    }

    /* ---- results ---- */
    void finishWin() {
        Profile p = P(); String td = today(), wk = weekId(); int n = levelNo, c = daily ? 4 : lvl.c; float dif = daily ? 0 : Math.min(1f, (n - 1) / 40f); int base = c * 3;
        int st = gs.moves <= base * (1.7f - dif * .35f) ? 3 : gs.moves <= base * (2.5f - dif * .5f) ? 2 : 1; Progress.Reward rw;
        if (daily) { boolean first = !td.equals(p.daily); rw = new Progress.Reward(); rw.first = first; if (first) { rw.line("Daily puzzle", 100); p.addStat("dailies", 1); Progress.event(p, "daily", 1, td, wk); } p.daily = td; }
        else {
            rw = Progress.levelReward(p, lvl, st); int prev = p.stars[n]; p.stars[n] = Math.max(prev, st); p.unl = Math.min(Engine.LEVELS, Math.max(p.unl, n + 1)); int gained = Math.max(0, st - prev);
            p.addStat("clears", 1); if (st == 3 && prev < 3) p.addStat("stars3", 1); if (lvl.boss && prev == 0) p.addStat("boss", 1); if (!hinted) p.addStat("hintFree", 1);
            if (lvl.has("locked")) p.addStat("locked", 1); if (lvl.has("frozen")) p.addStat("frozen", 1); if (lvl.has("time")) p.addStat("timeWins", 1);
            Progress.event(p, "clear", 1, td, wk); if (gained > 0) Progress.event(p, "star", gained, td, wk); Progress.event(p, "tube", tubesDone, td, wk); if (lvl.challenge()) Progress.event(p, "chal", 1, td, wk); if (!hinted) Progress.event(p, "hintfree", 1, td, wk);
            if (n == 1) p.tut = 1;
        }
        p.coins += rw.coins; p.hints += rw.hints; p.tubes += rw.tubes; p.undos += rw.undos;
        int k = 0; for (Progress.Badge b : Progress.checkBadges(p)) { queueToast("Badge unlocked: " + b.title); k++; } toastNext = now + 3.2f;
        host.save(); winStars = st; winMoves = gs.moves; winRw = rw; openDialog(D_WIN, ""); sfx(Sfx.WIN); vib(35);
        fx.confetti(W, 70, new int[]{0xFFE8B04B, 0xFFFF3B4E, 0xFF30D158, 0xFF2F7BFF, 0xFFFF5FB0, 0xFFFFD60A}, d); fx.burst(W / 2f, H * .3f, 30, Ui.BRASS, dp(220), dp(3.5f));
    }
    void afterBreak(Runnable r) { closeDialog(); host.ads().breakpoint(levelNo, false, r); }

    /* ======================= dialogs (bottom sheets) ======================= */
    final RectF sheetR = new RectF();
    void sheetFrame(Canvas c, float h) {
        float a = Fx.easeOutCubic((now - dlgT) / .3f); bp.setStyle(Paint.Style.FILL); bp.setShader(null); bp.setColor(alpha(0xFF02030A, .68f * a)); c.drawRect(0, 0, W, H, bp);
        rf.set(0, 0, W, H); hit(rf, "scrim", 0); float full = h + insetB, top = H - full * a; sheetR.set(dp(8), top, W - dp(8), H + dp(30));
        ui.fill(c, sheetR, dp(26), Ui.PANEL); ui.stroke(c, sheetR, dp(26), Ui.LINE, dp(1.2f)); rf.set(sheetR); hit(rf, "sheetbody", 0);
        rf.set(W / 2f - dp(22), top + dp(8), W / 2f + dp(22), top + dp(12)); ui.fill(c, rf, dp(2), Ui.LINE);
    }
    void drawDialog(Canvas c) {
        float cx = W / 2f, bw = W - dp(56);
        switch (dlg) {
            case D_PAUSE: { sheetFrame(c, dp(330)); float t = sheetR.top; ui.text(c, "Paused", cx, t + dp(58), 28, Ui.TEXT, Ui.C, true);
                rf.set(dp(28), t + dp(84), dp(28) + bw, t + dp(144)); btn(c, rf, "Resume", true, true, Ui.I_PLAY, "resume", 0);
                float hw = (bw - dp(10)) / 2; rf.set(dp(28), t + dp(158), dp(28) + hw, t + dp(214)); btn(c, rf, "Restart", false, true, Ui.I_RESTART, "restart", 0); rf.set(dp(38) + hw, t + dp(158), dp(38) + 2 * hw, t + dp(214)); btn(c, rf, "Quit", false, true, -1, "quit", 0); break; }
            case D_BRIEF: { int n = Integer.parseInt(dlgArg); Engine.Level L = levels[n]; float h = dp(250) + L.mods.length * dp(64); sheetFrame(c, h); float t = sheetR.top, y = t + dp(58);
                ui.text(c, (L.boss ? "Boss level " : "Level ") + n, cx, y, 26, Ui.TEXT, Ui.C, true); int st = P().stars[n]; for (int k = 0; k < 3; k++) ui.star(c, cx + (k - 1) * dp(32), y + dp(34), dp(12), st > k ? Ui.BRASS : 0xFF3A3F6E, true); y += dp(66);
                for (String m : L.mods) { rf.set(dp(24), y, W - dp(24), y + dp(56)); ui.fill(c, rf, dp(14), Ui.PANEL2); int ic = m.equals("boss") ? Ui.I_CROWN : m.equals("locked") ? Ui.I_LOCK : m.equals("frozen") ? Ui.I_SNOW : m.equals("time") ? Ui.I_TIMER : Ui.I_BAN; ui.icon(c, ic, dp(48), y + dp(28), dp(22), Ui.BRASS);
                    String ttl = m.equals("locked") ? "Locked tubes" : m.equals("frozen") ? "Frozen tubes" : m.equals("moves") ? L.limitMoves + " move limit" : m.equals("time") ? (L.limitTime / 60) + ":" + String.format(Locale.US, "%02d", L.limitTime % 60) + " time limit" : m.equals("noundo") ? "No undo" : m.equals("nohint") ? "No hints" : "Boss reward";
                    String sub = m.equals("locked") ? "Open after you complete a tube" : m.equals("frozen") ? "Thaws after a few moves" : m.equals("moves") ? "Finish before moves run out" : m.equals("time") ? "Beat the clock" : m.equals("boss") ? "Bigger rewards" : "Challenge bonus coins";
                    ui.text(c, ttl, dp(70), y + dp(24), 15.5f, Ui.TEXT, Ui.L, true); ui.text(c, sub, dp(70), y + dp(44), 12.5f, Ui.MUT, Ui.L, false); y += dp(64); }
                rf.set(dp(28), y + dp(6), dp(28) + bw, y + dp(66)); btn(c, rf, "Start", true, true, Ui.I_PLAY, "startbrief", n); break; }
            case D_WIN: { float h = dp(450) + (winRw == null ? 0 : winRw.label.size() * dp(30)); sheetFrame(c, h); float t = sheetR.top, el = now - dlgT;
                for (int k = 0; k < 3; k++) { float sc = Fx.easeOutBack((el - .3f - k * .22f) / .45f); float sx = cx + (k - 1) * dp(66), sy = t + dp(88) - (k == 1 ? dp(14) : 0); boolean on = k < winStars;
                    if (on) { ui.star(c, sx, sy, dp(34) * Math.max(0, sc), Ui.BRASS, true); } else ui.star(c, sx, sy, dp(30), 0xFF3A3F6E, true); if (on && el > .3f + k * .22f && el < .34f + k * .22f + dt) { sfx(Sfx.COIN); fx.burst(sx, sy, 10, Ui.BRASS, dp(150), dp(2.6f)); } }
                ui.text(c, daily ? "Daily puzzle done" : (lvl.boss ? "Boss defeated" : "Level " + levelNo + " cleared"), cx, t + dp(160), 26, Ui.TEXT, Ui.C, true);
                int need3 = (int) Math.floor((daily ? 4 : lvl.c) * 3 * (1.7f - (daily ? 0 : Math.min(1f, (levelNo - 1) / 40f)) * .35f)); ui.text(c, winMoves + " moves" + (winStars < 3 && !daily ? " · 3 stars: ≤ " + need3 : ""), cx, t + dp(186), 13.5f, Ui.MUT, Ui.C, false);
                float y = t + dp(208); if (winRw != null) { for (int k = 0; k < winRw.label.size(); k++) { rf.set(dp(28), y, W - dp(28), y + dp(26)); ui.fill(c, rf, dp(10), Ui.PANEL2); ui.text(c, winRw.label.get(k), dp(40), y + dp(18), 13.5f, Ui.TEXT, Ui.L, false); ui.text(c, "+" + winRw.amount.get(k), W - dp(40), y + dp(18), 13.5f, Ui.BRASS, Ui.R, true); y += dp(30); }
                    if (winRw.hints > 0) { rf.set(dp(28), y, W - dp(28), y + dp(26)); ui.fill(c, rf, dp(10), Ui.PANEL2); ui.text(c, "Boss bonus", dp(40), y + dp(18), 13.5f, Ui.TEXT, Ui.L, false); ui.text(c, "+" + winRw.hints + " hints", W - dp(40), y + dp(18), 13.5f, Ui.BRASS, Ui.R, true); y += dp(30); }
                    if (winRw.label.isEmpty()) { ui.text(c, "Replay — coins are paid only for new stars", cx, y + dp(18), 13.5f, Ui.MUT, Ui.C, false); y += dp(30); } }
                int shown = winRw == null ? 0 : (int) (winRw.coins * Fx.easeOutCubic((el - .8f) / 1f)); ui.icon(c, Ui.I_COIN, cx - dp(34), y + dp(24), dp(22), Ui.BRASS); ui.text(c, "+" + shown, cx - dp(16), y + dp(32), 24, Ui.BRASS, Ui.L, true);
                float by = y + dp(52); rf.set(dp(28), by, dp(28) + bw, by + dp(58)); btn(c, rf, daily ? "Back home" : levelNo >= Engine.LEVELS ? "Levels" : "Next level", true, true, -1, "next", 0); rf.set(dp(28), by + dp(70), dp(28) + bw, by + dp(124)); btn(c, rf, "Home", false, true, -1, "homeafter", 0); break; }
            case D_FAIL: { boolean time = dlgArg.equals("time"); Ads ads = host.ads(); boolean can = ads.rewardedReady(); sheetFrame(c, dp(can ? 360 : 300)); float t = sheetR.top;
                ui.text(c, time ? "Time's up" : "Out of moves", cx, t + dp(60), 28, Ui.TEXT, Ui.C, true); ui.text(c, "No coins lost — try again!", cx, t + dp(88), 14, Ui.MUT, Ui.C, false); float y = t + dp(112);
                if (can) { rf.set(dp(28), y, dp(28) + bw, y + dp(58)); btn(c, rf, time ? "Watch video · +30 seconds" : "Watch video · +6 moves", true, true, Ui.I_VIDEO, "extend", 0); y += dp(70); }
                rf.set(dp(28), y, dp(28) + bw, y + dp(58)); btn(c, rf, "Try again", !can, true, Ui.I_RESTART, "restart", 0); rf.set(dp(28), y + dp(70), dp(28) + bw, y + dp(126)); btn(c, rf, "Levels", false, true, -1, "quit", 0); break; }
            case D_STUCK: { boolean noU = lvl != null && lvl.has("noundo"); sheetFrame(c, dp(270)); float t = sheetR.top; ui.text(c, "No moves left", cx, t + dp(60), 28, Ui.TEXT, Ui.C, true);
                ui.text(c, noU ? "Restart to try a different approach." : "Undo a few moves, or restart.", cx, t + dp(88), 14, Ui.MUT, Ui.C, false); float y = t + dp(112);
                if (!noU) { rf.set(dp(28), y, dp(28) + bw, y + dp(58)); btn(c, rf, "Undo", true, true, Ui.I_UNDO, "undostuck", 0); y += dp(70); } rf.set(dp(28), y, dp(28) + bw, y + dp(56)); btn(c, rf, "Restart", noU, true, Ui.I_RESTART, "restart", 0); break; }
            case D_OFFER: { boolean hint = dlgArg.equals("hint"); Ads ads = host.ads(); boolean can = ads.rewardedReady(); sheetFrame(c, dp(can ? 330 : 270)); float t = sheetR.top;
                ui.text(c, "Out of " + (hint ? "hints" : "undos"), cx, t + dp(60), 26, Ui.TEXT, Ui.C, true); ui.text(c, can ? "Watch a short optional video, or visit the Shop." : "Get more in the Shop.", cx, t + dp(88), 14, Ui.MUT, Ui.C, false); float y = t + dp(112);
                if (can) { rf.set(dp(28), y, dp(28) + bw, y + dp(58)); btn(c, rf, "Watch video · +" + (hint ? "1 hint" : "3 undos"), true, true, Ui.I_VIDEO, "offeradd", 0); y += dp(70); }
                float hw = (bw - dp(10)) / 2; rf.set(dp(28), y, dp(28) + hw, y + dp(54)); btn(c, rf, "Shop", !can, true, Ui.I_BAG, "offershop", 0); rf.set(dp(38) + hw, y, dp(38) + 2 * hw, y + dp(54)); btn(c, rf, "Not now", false, true, -1, "resume", 0); break; }
        }
    }

    /* ======================= actions ======================= */
    /** Index-style actions must never crash on a stray argument. */
    boolean badArg(String a, int g) {
        switch (a) {
            case "lvl": case "startbrief": return g < 1 || g > Engine.LEVELS || levels[g] == null;
            case "tube": return gs == null || g < 0 || g >= gs.T.n;
            case "shopitem": return g < 0 || g >= shopNames().length;
            case "boost": return g < 0 || g >= BOOST_PRICE.length;
            case "claimq": return g < 0 || g >= (missTab == 0 ? Progress.dailyMissions(today()).length : Progress.WEEKLY.length);
            case "claimb": return g < 0 || g >= Progress.BADGES.length;
            case "claimm": return g < 0 || g >= Progress.MILESTONES.length;
            case "toggle": return g < 0 || g > 3;
            case "shoptab": return g < 0 || g >= SHOP_TABS.length;
            case "misstab": return g < 0 || g >= MISS_TABS.length;
            case "startdaily": return false;
            default: return false;
        }
    }
    void act(String a, int g) {
        if (badArg(a, g)) return;
        if (gs == null && (a.equals("undo") || a.equals("hint") || a.equals("extra") || a.equals("undostuck") || a.equals("extend") || a.equals("offeradd") || a.equals("next") || a.equals("homeafter"))) return;
        sfx(Sfx.CLICK); Profile p = P(); Ads ads = host.ads();
        switch (a) {
            case "back": goTo(HOME); break; case "play": goTo(LEVELS); break; case "daily": goTo(DAILY); break; case "missions": goTo(MISSIONS); break; case "shop": goTo(SHOP); break; case "settings": goTo(SETTINGS); break;
            case "lvl": { if (g > p.unl) { sfx(Sfx.BAD); toast("Clear earlier levels to unlock"); break; } Engine.Level L = levels[g]; if (L != null && L.mods.length > 0) openDialog(D_BRIEF, String.valueOf(g)); else startLevel(g); break; }
            case "startbrief": startLevel(g); break;
            case "tube": tapTube(g); break;
            case "pause": openDialog(D_PAUSE, ""); break; case "undo": doUndo(); break; case "hint": doHint(); break; case "extra": doExtra(); break;
            case "restart": closeDialog(); if (daily) startDaily(); else startLevel(levelNo); break;
            case "resume": closeDialog(); break; case "quit": closeDialog(); goTo(daily ? HOME : LEVELS); break; case "scrim": if (dlg == D_PAUSE || dlg == D_OFFER || dlg == D_BRIEF) closeDialog(); break;
            case "undostuck": closeDialog(); endKind = 0; doUndo(); break; case "skiptut": tut = -1; p.tut = 1; host.save(); break;
            case "next": afterBreak(() -> { if (daily || levelNo >= Engine.LEVELS) goTo(daily ? HOME : LEVELS); else startLevel(levelNo + 1); }); break;
            case "homeafter": afterBreak(() -> goTo(HOME)); break;
            case "extend": { final boolean time = dlgArg.equals("time"); ads.showRewarded("fail_" + dlgArg, today(), (ok, msg) -> { if (ok) { closeDialog(); over = false; endKind = 0; if (time) bonusT += 30; else bonusMoves += 6; toast(time ? "+30 seconds" : "+6 moves"); } else toast(msg); }); break; }
            case "offeradd": { final boolean hint = dlgArg.equals("hint"); ads.showRewarded(hint ? "hint" : "undo", today(), (ok, msg) -> { if (ok) { if (hint) P().hints++; else P().undos += 3; host.save(); closeDialog(); toast(hint ? "+1 hint" : "+3 undos"); sfx(Sfx.COIN); } else toast(msg); }); break; }
            case "offershop": closeDialog(); goTo(SHOP); shopTab = 3; break;
            case "shoptab": shopTab = g; scrollY = 0; break; case "misstab": missTab = g; scrollY = 0; break;
            case "shopitem": { String name = shopNames()[g], key = shopPrefix() + name; boolean own = p.own.contains(key); int price = shopPrice(g);
                if (!own) { if (price < 0) { sfx(Sfx.BAD); toast("Unlock: " + shopHow(g)); break; } if (p.coins < price) { sfx(Sfx.BAD); toast("Not enough coins"); break; } p.coins -= price; p.own.add(key); sfx(Sfx.COIN); }
                if (shopTab == 0) p.theme = name; else if (shopTab == 1) p.tube = name; else p.back = name; host.save(); break; }
            case "boost": { if (p.coins < BOOST_PRICE[g]) { sfx(Sfx.BAD); toast("Not enough coins"); break; } p.coins -= BOOST_PRICE[g]; if (g == 0) p.hints += 3; else if (g == 1) p.hints += 10; else if (g == 2) p.undos += 5; else p.tubes += 3; host.save(); sfx(Sfx.COIN); break; }
            case "freecoins": ads.showRewarded("coins", today(), (ok, msg) -> { if (ok) { P().coins += 60; host.save(); sfx(Sfx.COIN); toast("+60 coins"); fx.burst(W / 2f, H * .3f, 20, Ui.BRASS, dp(180), dp(3)); } else toast(msg); }); break;
            case "freehint": ads.showRewarded("hint", today(), (ok, msg) -> { if (ok) { P().hints++; host.save(); sfx(Sfx.COIN); toast("+1 hint"); } else toast(msg); }); break;
            case "claimq": { Progress.Quest q = Progress.claimQuest(p, missTab == 0, (missTab == 0 ? Progress.dailyMissions(today()) : Progress.WEEKLY)[g].id, today(), weekId()); claimFx(q != null, q == null ? "" : "+" + q.coins + " coins"); break; }
            case "claimb": { Progress.Badge b = Progress.claimBadge(p, Progress.BADGES[g].id); claimFx(b != null, b == null ? "" : "+" + b.coins + " coins" + (b.own != null ? " · new tube skin!" : "")); break; }
            case "claimm": { Progress.Milestone m = Progress.claimMilestone(p, Progress.MILESTONES[g].id); claimFx(m != null, m == null ? "" : "+" + m.coins + " coins · " + m.title); break; }
            case "toggle": if (g == 0) p.snd = !p.snd; else if (g == 1) p.vib = !p.vib; else if (g == 2) p.cb = !p.cb; else p.rm = !p.rm; host.sfx().enabled = p.snd; host.save(); break;
            case "privacy": ads.showPrivacyOptions(); break;
            case "reset": { if (now * 1000 - resetArm < 3000 && resetArm > 0) { resetArm = 0; host.resetProgress(); themeName = ""; backName = ""; goTo(HOME); toast("Progress erased"); } else resetArm = (long) (now * 1000); break; }
            case "claimday": { if (today().equals(p.last)) break; p.coins += DAILY_RW[p.day]; if (p.day == 6) { p.addStat("streak", 1); for (Progress.Badge b : Progress.checkBadges(p)) queueToast("Badge unlocked: " + b.title); } toast("+" + DAILY_RW[p.day] + " coins"); p.day = (p.day + 1) % 7; p.last = today(); host.save(); sfx(Sfx.COIN); fx.burst(W / 2f, H * .3f, 26, Ui.BRASS, dp(200), dp(3)); break; }
            case "playdaily": startDaily(); break;
            default: break;
        }
    }
    void claimFx(boolean ok, String msg) { if (!ok) { sfx(Sfx.BAD); return; } host.save(); sfx(Sfx.COIN); toast("Claimed: " + msg); fx.burst(W / 2f, H * .32f, 22, Ui.BRASS, dp(190), dp(3)); }
}
