package com.colortrap.game;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** Canvas drawing helpers + vector icons in the navy/gold theme. */
public final class Ui {
    public static final int INK = 0xFF0F1122, PANEL = 0xFF22264A, PANEL2 = 0xFF171A2E, LINE = 0xFF383E6B, BRASS = 0xFFE8B04B, BRASS2 = 0xFFA8761F,
            TEXT = 0xFFF4EFE4, MUT = 0xFF9EA4CC, BAD = 0xFFE5645C, GOOD = 0xFF30D158, DARKTXT = 0xFF2A1D05;
    public static final int I_BACK = 0, I_PAUSE = 1, I_UNDO = 2, I_BULB = 3, I_PLUS = 4, I_RESTART = 5, I_GEAR = 6, I_STAR = 7, I_COIN = 8, I_LOCK = 9, I_SNOW = 10,
            I_PLAY = 11, I_CAL = 12, I_MEDAL = 13, I_BAG = 14, I_TIMER = 15, I_BAN = 16, I_CROWN = 17, I_CHECK = 18, I_VIDEO = 19;

    public final float d;                       // density
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path(); private final RectF tmp = new RectF();
    private final Typeface bold = Typeface.create("sans-serif-black", Typeface.BOLD), med = Typeface.create("sans-serif-medium", Typeface.NORMAL);

    public Ui(float density) { d = density; t.setTextAlign(Paint.Align.LEFT); }
    public float dp(float v) { return v * d; }
    public Paint paint() { return p; }

    public void fill(Canvas c, RectF r, float rad, int col) { p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(col); c.drawRoundRect(r, rad, rad, p); }
    public void stroke(Canvas c, RectF r, float rad, int col, float w) { p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w); p.setColor(col); c.drawRoundRect(r, rad, rad, p); p.setStyle(Paint.Style.FILL); }
    public void circle(Canvas c, float x, float y, float r, int col) { p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(col); c.drawCircle(x, y, r, p); }
    public void vgrad(Canvas c, RectF r, float rad, int top, int bot) { p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(0, r.top, 0, r.bottom, top, bot, Shader.TileMode.CLAMP)); c.drawRoundRect(r, rad, rad, p); p.setShader(null); }

    /* ---------------- text ---------------- */
    public static final int L = 0, C = 1, R = 2;
    public void text(Canvas c, String s, float x, float y, float sp, int col, int align, boolean isBold) {
        t.setTypeface(isBold ? bold : med); t.setTextSize(sp * d); t.setColor(col); t.setTextAlign(align == C ? Paint.Align.CENTER : align == R ? Paint.Align.RIGHT : Paint.Align.LEFT);
        c.drawText(s, x, y, t);
    }
    /** Text vertically centred on cy. */
    public void textC(Canvas c, String s, float x, float cy, float sp, int col, int align, boolean isBold) { text(c, s, x, cy + sp * d * .35f, sp, col, align, isBold); }
    public float textW(String s, float sp, boolean isBold) { t.setTypeface(isBold ? bold : med); t.setTextSize(sp * d); return t.measureText(s); }
    /** Greedy word wrap; returns lines used. */
    public int wrap(Canvas c, String s, float x, float y, float maxW, float sp, int col, int align, float lineH) {
        String[] words = s.split(" "); StringBuilder line = new StringBuilder(); int n = 0;
        for (String w : words) {
            String test = line.length() == 0 ? w : line + " " + w;
            if (textW(test, sp, false) > maxW && line.length() > 0) { text(c, line.toString(), x, y + n * lineH, sp, col, align, false); n++; line = new StringBuilder(w); } else line = new StringBuilder(test);
        }
        if (line.length() > 0) { text(c, line.toString(), x, y + n * lineH, sp, col, align, false); n++; }
        return n;
    }

    /* ---------------- components ---------------- */
    public void panel(Canvas c, RectF r) { fill(c, r, dp(18), PANEL); stroke(c, r, dp(18), LINE, dp(1)); }
    /** Primary (gold) or secondary button with a press scale. */
    public void button(Canvas c, RectF r, String label, boolean primary, float scale, boolean enabled, int iconType) {
        c.save(); c.scale(scale, scale, r.centerX(), r.centerY());
        float rad = dp(16), lip = dp(4);
        if (primary) {
            tmp.set(r.left, r.top + lip, r.right, r.bottom + lip); fill(c, tmp, rad, enabled ? BRASS2 : 0xFF3A3F66);
            tmp.set(r); vgrad(c, tmp, rad, enabled ? 0xFFF3C766 : 0xFF4A5080, enabled ? BRASS : 0xFF3F4570);
        } else { tmp.set(r.left, r.top + lip, r.right, r.bottom + lip); fill(c, tmp, rad, 0xFF11132A); tmp.set(r); fill(c, tmp, rad, enabled ? PANEL : 0xFF1A1D38); stroke(c, tmp, rad, LINE, dp(1)); }
        int fg = primary ? (enabled ? DARKTXT : MUT) : (enabled ? TEXT : MUT);
        float tw = textW(label, 17, true), iw = iconType >= 0 ? dp(26) : 0, x0 = r.centerX() - (tw + iw) / 2;
        if (iconType >= 0) icon(c, iconType, x0 + dp(10), r.centerY(), dp(20), fg);
        textC(c, label, x0 + iw, r.centerY(), 17, fg, L, true);
        c.restore();
    }
    public void chip(Canvas c, RectF r, String label, int icon, int iconCol) {
        fill(c, r, r.height() / 2, PANEL); stroke(c, r, r.height() / 2, LINE, dp(1));
        icon(c, icon, r.left + dp(18), r.centerY(), dp(18), iconCol); textC(c, label, r.left + dp(32), r.centerY(), 16, TEXT, L, true);
    }
    public void bar(Canvas c, RectF r, float frac) { fill(c, r, r.height() / 2, PANEL2); if (frac > 0) { tmp.set(r.left, r.top, r.left + Math.max(r.height(), r.width() * Math.min(1, frac)), r.bottom); vgrad(c, tmp, r.height() / 2, 0xFFF3C766, BRASS2); } }
    public void roundIcon(Canvas c, RectF r, int icon, float scale, boolean enabled) {
        c.save(); c.scale(scale, scale, r.centerX(), r.centerY()); fill(c, r, dp(14), PANEL); stroke(c, r, dp(14), LINE, dp(1));
        icon(c, icon, r.centerX(), r.centerY(), dp(22), enabled ? TEXT : MUT); c.restore();
    }

    /* ---------------- icons ---------------- */
    public void star(Canvas c, float cx, float cy, float rad, int col, boolean filled) {
        path.reset(); for (int i = 0; i < 10; i++) { double a = -Math.PI / 2 + i * Math.PI / 5; float r = (i % 2 == 0) ? rad : rad * .45f; float x = cx + (float) Math.cos(a) * r, y = cy + (float) Math.sin(a) * r; if (i == 0) path.moveTo(x, y); else path.lineTo(x, y); }
        path.close(); p.setShader(null); p.setColor(col); p.setStyle(filled ? Paint.Style.FILL : Paint.Style.STROKE); p.setStrokeWidth(dp(1.6f)); p.setStrokeJoin(Paint.Join.ROUND); c.drawPath(path, p); p.setStyle(Paint.Style.FILL);
    }
    public void icon(Canvas c, int type, float cx, float cy, float s, int col) {
        float h = s / 2, w = Math.max(dp(1.8f), s * .1f);
        p.setShader(null); p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
        switch (type) {
            case I_BACK: path.reset(); path.moveTo(cx + h * .3f, cy - h * .8f); path.lineTo(cx - h * .5f, cy); path.lineTo(cx + h * .3f, cy + h * .8f); c.drawPath(path, p); break;
            case I_PAUSE: p.setStyle(Paint.Style.FILL); tmp.set(cx - h * .6f, cy - h * .7f, cx - h * .15f, cy + h * .7f); c.drawRoundRect(tmp, w, w, p); tmp.set(cx + h * .15f, cy - h * .7f, cx + h * .6f, cy + h * .7f); c.drawRoundRect(tmp, w, w, p); break;
            case I_UNDO: case I_RESTART: {
                tmp.set(cx - h * .7f, cy - h * .7f, cx + h * .7f, cy + h * .7f); path.reset();
                if (type == I_UNDO) { path.arcTo(tmp, -150, 270, true); c.drawPath(path, p); path.reset(); path.moveTo(cx - h * .95f, cy - h * .15f); path.lineTo(cx - h * .55f, cy - h * .6f); path.lineTo(cx - h * .1f, cy - h * .1f); c.drawPath(path, p); }
                else { path.arcTo(tmp, -60, 280, true); c.drawPath(path, p); path.reset(); path.moveTo(cx + h * .75f, cy - h * .75f); path.lineTo(cx + h * .45f, cy - h * .3f); path.lineTo(cx + h * .95f, cy - h * .2f); c.drawPath(path, p); }
                break; }
            case I_BULB: c.drawCircle(cx, cy - h * .15f, h * .6f, p); c.drawLine(cx - h * .3f, cy + h * .65f, cx + h * .3f, cy + h * .65f, p); c.drawLine(cx - h * .2f, cy + h * .95f, cx + h * .2f, cy + h * .95f, p); break;
            case I_PLUS: c.drawLine(cx - h * .7f, cy, cx + h * .7f, cy, p); c.drawLine(cx, cy - h * .7f, cx, cy + h * .7f, p); break;
            case I_CHECK: path.reset(); path.moveTo(cx - h * .7f, cy); path.lineTo(cx - h * .2f, cy + h * .55f); path.lineTo(cx + h * .75f, cy - h * .6f); c.drawPath(path, p); break;
            case I_GEAR: c.drawCircle(cx, cy, h * .38f, p); for (int i = 0; i < 8; i++) { double a = i * Math.PI / 4; c.drawLine(cx + (float) Math.cos(a) * h * .62f, cy + (float) Math.sin(a) * h * .62f, cx + (float) Math.cos(a) * h * .9f, cy + (float) Math.sin(a) * h * .9f, p); } c.drawCircle(cx, cy, h * .62f, p); break;
            case I_STAR: star(c, cx, cy, h, col, true); break;
            case I_COIN: p.setStyle(Paint.Style.STROKE); c.drawCircle(cx, cy, h * .85f, p); c.drawCircle(cx, cy, h * .42f, p); break;
            case I_LOCK: tmp.set(cx - h * .6f, cy - h * .1f, cx + h * .6f, cy + h * .8f); p.setStyle(Paint.Style.FILL); c.drawRoundRect(tmp, w, w, p); p.setStyle(Paint.Style.STROKE); tmp.set(cx - h * .38f, cy - h * .85f, cx + h * .38f, cy + h * .25f); path.reset(); path.arcTo(tmp, 180, 180, true); path.lineTo(cx + h * .38f, cy - h * .1f); c.drawPath(path, p); break;
            case I_SNOW: for (int i = 0; i < 3; i++) { double a = i * Math.PI / 3 + Math.PI / 6; float dx = (float) Math.cos(a) * h * .9f, dy = (float) Math.sin(a) * h * .9f; c.drawLine(cx - dx, cy - dy, cx + dx, cy + dy, p); } break;
            case I_PLAY: p.setStyle(Paint.Style.FILL); path.reset(); path.moveTo(cx - h * .5f, cy - h * .75f); path.lineTo(cx + h * .8f, cy); path.lineTo(cx - h * .5f, cy + h * .75f); path.close(); c.drawPath(path, p); break;
            case I_CAL: tmp.set(cx - h * .8f, cy - h * .65f, cx + h * .8f, cy + h * .8f); c.drawRoundRect(tmp, w * 1.5f, w * 1.5f, p); c.drawLine(cx - h * .8f, cy - h * .15f, cx + h * .8f, cy - h * .15f, p); c.drawLine(cx - h * .4f, cy - h * .9f, cx - h * .4f, cy - h * .4f, p); c.drawLine(cx + h * .4f, cy - h * .9f, cx + h * .4f, cy - h * .4f, p); break;
            case I_MEDAL: c.drawCircle(cx, cy + h * .2f, h * .55f, p); c.drawLine(cx - h * .35f, cy - h * .9f, cx - h * .1f, cy - h * .3f, p); c.drawLine(cx + h * .35f, cy - h * .9f, cx + h * .1f, cy - h * .3f, p); break;
            case I_BAG: tmp.set(cx - h * .7f, cy - h * .3f, cx + h * .7f, cy + h * .85f); c.drawRoundRect(tmp, w * 1.5f, w * 1.5f, p); tmp.set(cx - h * .3f, cy - h * .85f, cx + h * .3f, cy + h * .1f); path.reset(); path.arcTo(tmp, 180, 180, true); c.drawPath(path, p); break;
            case I_TIMER: c.drawCircle(cx, cy + h * .1f, h * .75f, p); c.drawLine(cx, cy + h * .1f, cx, cy - h * .35f, p); c.drawLine(cx - h * .25f, cy - h * .95f, cx + h * .25f, cy - h * .95f, p); break;
            case I_BAN: c.drawCircle(cx, cy, h * .78f, p); c.drawLine(cx - h * .55f, cy - h * .55f, cx + h * .55f, cy + h * .55f, p); break;
            case I_CROWN: p.setStyle(Paint.Style.FILL); path.reset(); path.moveTo(cx - h * .8f, cy + h * .6f); path.lineTo(cx - h * .8f, cy - h * .4f); path.lineTo(cx - h * .35f, cy + h * .05f); path.lineTo(cx, cy - h * .65f); path.lineTo(cx + h * .35f, cy + h * .05f); path.lineTo(cx + h * .8f, cy - h * .4f); path.lineTo(cx + h * .8f, cy + h * .6f); path.close(); c.drawPath(path, p); break;
            case I_VIDEO: tmp.set(cx - h * .85f, cy - h * .6f, cx + h * .85f, cy + h * .6f); c.drawRoundRect(tmp, w * 2, w * 2, p); p.setStyle(Paint.Style.FILL); path.reset(); path.moveTo(cx - h * .2f, cy - h * .3f); path.lineTo(cx + h * .35f, cy); path.lineTo(cx - h * .2f, cy + h * .3f); path.close(); c.drawPath(path, p); break;
            default: break;
        }
        p.setStyle(Paint.Style.FILL);
    }
}
