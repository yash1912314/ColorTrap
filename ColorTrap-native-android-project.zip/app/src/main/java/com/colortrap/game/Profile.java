package com.colortrap.game;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** All persistent player data. Plain Java so it can be unit-tested; serialised by SaveManager. */
public final class Profile {
    /** Lets other classes always see the live profile even after a reset replaces it. */
    public interface Provider { Profile get(); }

    public int coins = 300, hints = 3, tubes = 2, undos = 3, unl = 1, day = 0, tut = 0;
    public boolean snd = true, vib = true, cb = false, rm = false, noads = false;
    public String last = "", daily = "";
    public int[] stars = new int[Engine.LEVELS + 2];
    public String theme = "Classic", tube = "Glass", back = "Ink";
    public Set<String> own = new LinkedHashSet<>();
    public Map<String, Integer> st = new HashMap<>();      // lifetime stats
    public Map<String, Integer> ach = new HashMap<>();     // badge id -> 1 unlocked / 2 claimed
    public Map<String, Integer> ms = new HashMap<>();      // milestone id -> 1 claimed
    public String dmDate = "", wkId = "";
    public Map<String, Integer> dmP = new HashMap<>(), dmC = new HashMap<>(), wkP = new HashMap<>(), wkC = new HashMap<>();
    public long adLast; public int adN; public String adDay = ""; public int adCoinN;

    public Profile() { own.add("T:Classic"); own.add("T:Accessible"); own.add("U:Glass"); own.add("B:Ink"); }

    public int stat(String k) { Integer v = st.get(k); return v == null ? 0 : v; }
    public void addStat(String k, int n) { st.put(k, stat(k) + n); }
    public int cleared() { int c = 0; for (int i = 1; i <= Engine.LEVELS; i++) if (stars[i] > 0) c++; return c; }
    public int totalStars() { int c = 0; for (int i = 1; i <= Engine.LEVELS; i++) c += stars[i]; return c; }

    /* ---- serialisation: key=value lines ---- */
    private static void map(StringBuilder sb, String p, Map<String, Integer> m) { for (Map.Entry<String, Integer> e : m.entrySet()) sb.append(p).append('.').append(e.getKey()).append('=').append(e.getValue()).append('\n'); }
    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("v=1\ncoins=").append(coins).append("\nhints=").append(hints).append("\ntubes=").append(tubes).append("\nundos=").append(undos)
          .append("\nunl=").append(unl).append("\nday=").append(day).append("\ntut=").append(tut)
          .append("\nsnd=").append(snd ? 1 : 0).append("\nvib=").append(vib ? 1 : 0).append("\ncb=").append(cb ? 1 : 0).append("\nrm=").append(rm ? 1 : 0).append("\nnoads=").append(noads ? 1 : 0)
          .append("\nlast=").append(last).append("\ndaily=").append(daily).append("\ntheme=").append(theme).append("\ntube=").append(tube).append("\nback=").append(back)
          .append("\ndmDate=").append(dmDate).append("\nwkId=").append(wkId).append("\nadLast=").append(adLast).append("\nadN=").append(adN).append("\nadDay=").append(adDay).append("\nadCoinN=").append(adCoinN).append('\n');
        StringBuilder s = new StringBuilder(); for (int i = 1; i <= Engine.LEVELS; i++) if (stars[i] > 0) s.append(i).append(':').append(stars[i]).append(',');
        sb.append("stars=").append(s).append('\n').append("own=").append(String.join(",", own)).append('\n');
        map(sb, "st", st); map(sb, "ach", ach); map(sb, "ms", ms); map(sb, "dmP", dmP); map(sb, "dmC", dmC); map(sb, "wkP", wkP); map(sb, "wkC", wkC);
        return sb.toString();
    }
    private static int toInt(String v, int d) { try { return Integer.parseInt(v.trim()); } catch (Exception e) { return d; } }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    public static Profile parse(String text) {
        Profile p = new Profile(); if (text == null) return p;
        for (String line : text.split("\n")) {
            int q = line.indexOf('='); if (q <= 0) continue; String k = line.substring(0, q), v = line.substring(q + 1);
            switch (k) {
                case "coins": p.coins = clamp(toInt(v, 300), 0, 1000000000); break; case "hints": p.hints = clamp(toInt(v, 3), 0, 9999); break;
                case "tubes": p.tubes = clamp(toInt(v, 2), 0, 9999); break; case "undos": p.undos = clamp(toInt(v, 3), 0, 9999); break;
                case "unl": p.unl = clamp(toInt(v, 1), 1, Engine.LEVELS); break; case "day": p.day = clamp(toInt(v, 0), 0, 6); break; case "tut": p.tut = toInt(v, 0); break;
                case "snd": p.snd = v.equals("1"); break; case "vib": p.vib = v.equals("1"); break; case "cb": p.cb = v.equals("1"); break; case "rm": p.rm = v.equals("1"); break; case "noads": p.noads = v.equals("1"); break;
                case "last": p.last = v; break; case "daily": p.daily = v; break; case "theme": p.theme = v; break; case "tube": p.tube = v; break; case "back": p.back = v; break;
                case "dmDate": p.dmDate = v; break; case "wkId": p.wkId = v; break; case "adLast": try { p.adLast = Long.parseLong(v.trim()); } catch (Exception e) { } break;
                case "adN": p.adN = toInt(v, 0); break; case "adDay": p.adDay = v; break; case "adCoinN": p.adCoinN = toInt(v, 0); break;
                case "stars": for (String s : v.split(",")) { String[] kv = s.split(":"); if (kv.length == 2) { int n = toInt(kv[0], 0), c = toInt(kv[1], 0); if (n >= 1 && n <= Engine.LEVELS) p.stars[n] = clamp(c, 0, 3); } } break;
                case "own": for (String s : v.split(",")) if (!s.isEmpty()) p.own.add(s); break;
                default: {
                    int d = k.indexOf('.'); if (d < 0) break; String pre = k.substring(0, d), key = k.substring(d + 1); int val = toInt(v, 0);
                    Map<String, Integer> m = pre.equals("st") ? p.st : pre.equals("ach") ? p.ach : pre.equals("ms") ? p.ms : pre.equals("dmP") ? p.dmP : pre.equals("dmC") ? p.dmC : pre.equals("wkP") ? p.wkP : pre.equals("wkC") ? p.wkC : null;
                    if (m != null) m.put(key, val);
                }
            }
        }
        // a level the player has reached implies the previous ones were cleared only via stars, so just keep unl sane
        return p;
    }
}
