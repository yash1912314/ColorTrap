package com.colortrap.game;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.File;
import java.io.FileOutputStream;

/** Sound effects synthesised at first launch into small WAV files (no assets), played via SoundPool. */
public final class Sfx {
    public static final int CLICK = 0, SEL = 1, POUR = 2, DROP = 3, DONE = 4, WIN = 5, BAD = 6, COIN = 7, UNLOCK = 8, LOSE = 9, COUNT = 10;
    private static final int SR = 22050;
    private SoundPool pool; private final int[] ids = new int[COUNT]; private final boolean[] ready = new boolean[COUNT];
    public boolean enabled = true;

    public Sfx(final Context ctx) {
        pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build();
        pool.setOnLoadCompleteListener((sp, id, status) -> { if (status == 0) for (int i = 0; i < COUNT; i++) if (ids[i] == id) ready[i] = true; });
        new Thread(() -> {                                  // generate off the UI thread so startup stays instant
            try { File dir = new File(ctx.getCacheDir(), "sfx"); dir.mkdirs();
                for (int i = 0; i < COUNT; i++) { File f = new File(dir, "s" + i + ".wav"); if (!f.exists()) write(f, synth(i)); ids[i] = pool.load(f.getAbsolutePath(), 1); }
            } catch (Exception ignored) { }
        }).start();
    }
    public void play(int s) { if (enabled && pool != null && s >= 0 && s < COUNT && ready[s]) pool.play(ids[s], .8f, .8f, 1, 0, 1f); }
    public void release() { if (pool != null) { pool.release(); pool = null; } }

    /* ---------- synthesis ---------- */
    private static short[] tone(float f0, float f1, float sec, float vol, int wave, float decay) {
        int n = (int) (SR * sec); short[] o = new short[n]; double ph = 0;
        for (int i = 0; i < n; i++) { float u = i / (float) n, f = f0 + (f1 - f0) * u; ph += 2 * Math.PI * f / SR;
            double v = wave == 0 ? Math.sin(ph) : wave == 1 ? (Math.sin(ph) > 0 ? 1 : -1) * .6 : 2 / Math.PI * Math.asin(Math.sin(ph));
            double env = Math.min(1, i / (SR * .004)) * Math.exp(-decay * u); o[i] = (short) (v * env * vol * 32000); }
        return o;
    }
    private static short[] cat(short[]... parts) { int n = 0; for (short[] p : parts) n += p.length; short[] o = new short[n]; int k = 0; for (short[] p : parts) { System.arraycopy(p, 0, o, k, p.length); k += p.length; } return o; }
    private static short[] mix(short[] a, short[] b, int off) { short[] o = new short[Math.max(a.length, b.length + off)]; System.arraycopy(a, 0, o, 0, a.length); for (int i = 0; i < b.length; i++) o[i + off] = (short) Math.max(-32000, Math.min(32000, o[i + off] + b[i])); return o; }
    private static short[] arp(float[] notes, float step, float len, float vol) { short[] o = new short[0]; for (int i = 0; i < notes.length; i++) o = mix(o, tone(notes[i], notes[i], len, vol, 2, 3.5f), (int) (SR * step * i)); return o; }
    static short[] synth(int s) {
        switch (s) {
            case CLICK: return tone(1300, 900, .035f, .35f, 0, 5);
            case SEL: return tone(620, 900, .09f, .4f, 2, 3);
            case POUR: { short[] a = tone(300, 520, .16f, .35f, 0, 2.5f); return mix(a, tone(420, 250, .12f, .25f, 0, 3), (int) (SR * .06)); }
            case DROP: return tone(520, 260, .07f, .5f, 0, 5);
            case DONE: return arp(new float[]{523, 659, 784}, .07f, .22f, .4f);
            case WIN: return arp(new float[]{523, 659, 784, 1047, 1319}, .09f, .32f, .38f);
            case BAD: return tone(190, 140, .13f, .35f, 1, 3);
            case COIN: return mix(tone(1568, 1568, .08f, .35f, 2, 3), tone(2093, 2093, .16f, .35f, 2, 4), (int) (SR * .07));
            case UNLOCK: return tone(380, 980, .22f, .4f, 2, 2);
            default: return cat(tone(420, 300, .16f, .4f, 2, 2), tone(300, 170, .24f, .4f, 2, 3));
        }
    }
    private static void write(File f, short[] pcm) throws Exception {
        int n = pcm.length * 2; java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream(44 + n);
        java.nio.ByteBuffer h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        h.put("RIFF".getBytes()).putInt(36 + n).put("WAVE".getBytes()).put("fmt ".getBytes()).putInt(16).putShort((short) 1).putShort((short) 1).putInt(SR).putInt(SR * 2).putShort((short) 2).putShort((short) 16).put("data".getBytes()).putInt(n);
        b.write(h.array()); java.nio.ByteBuffer d = java.nio.ByteBuffer.allocate(n).order(java.nio.ByteOrder.LITTLE_ENDIAN); for (short v : pcm) d.putShort(v); b.write(d.array());
        FileOutputStream o = new FileOutputStream(f); o.write(b.toByteArray()); o.close();
    }
}
