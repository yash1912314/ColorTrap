package com.colortrap.game;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * AdMob + UMP consent. The game decides WHEN (never during a live puzzle, always optional, paced);
 * this class only loads/shows. Every failure degrades silently so ads can never block play.
 */
public final class Ads {
    public interface Result { void done(boolean rewarded, String message); }
    private static final long MIN_GAP = 180_000L; private static final int EVERY_N = 3, FIRST_LEVEL = 6, COIN_CAP = 6;

    private final Activity act; private final FrameLayout bannerHost; private final Profile.Provider prof;
    private final long t0 = System.currentTimeMillis(); private final AtomicBoolean started = new AtomicBoolean();
    private ConsentInformation consent; private RewardedAd rewarded; private InterstitialAd inter; private AdView banner; private boolean wantBanner, earned, showing, loadingR;
    public boolean privacyRequired;

    public Ads(Activity a, FrameLayout host, Profile.Provider p) { act = a; bannerHost = host; prof = p; }
    private static boolean cfg(String id) { return id != null && !id.contains("REPLACE"); }
    private Profile p() { return prof.get(); }

    public void init() {
        if (p().noads) return;
        consent = UserMessagingPlatform.getConsentInformation(act);
        consent.requestConsentInfoUpdate(act, new ConsentRequestParameters.Builder().build(),
            () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(act, e -> start()), e -> start());
    }
    private void start() {
        if (consent == null || !consent.canRequestAds()) return;               // no consent => no ad requests
        privacyRequired = consent.getPrivacyOptionsRequirementStatus() == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
        if (started.compareAndSet(false, true)) new Thread(() -> MobileAds.initialize(act, s -> act.runOnUiThread(() -> { preload(); if (wantBanner) buildBanner(); }))).start();
    }
    public void showPrivacyOptions() { UserMessagingPlatform.showPrivacyOptionsForm(act, e -> start()); }
    public void preload() {
        if (!started.get() || p().noads) return;
        if (rewarded == null && !loadingR && cfg(BuildConfig.AD_REWARDED)) { loadingR = true;
            RewardedAd.load(act, BuildConfig.AD_REWARDED, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(@NonNull RewardedAd ad) { rewarded = ad; loadingR = false; }
                @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { rewarded = null; loadingR = false; } }); }
        if (inter == null && cfg(BuildConfig.AD_INTERSTITIAL))
            InterstitialAd.load(act, BuildConfig.AD_INTERSTITIAL, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(@NonNull InterstitialAd ad) { inter = ad; }
                @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { inter = null; } });
    }
    public boolean enabled() { return started.get() && !p().noads; }
    public boolean rewardedReady() { return enabled() && rewarded != null && !showing; }
    public boolean loading() { return enabled() && rewarded == null; }
    public int coinAdsLeft(String today) { Profile p = p(); if (!today.equals(p.adDay)) { p.adDay = today; p.adCoinN = 0; } return Math.max(0, COIN_CAP - p.adCoinN); }

    /** Optional rewarded video. `placement` "coins" is capped per day. The reward is granted only if the player watched it. */
    public void showRewarded(String placement, String today, Result r) {
        if (!rewardedReady()) { preload(); r.done(false, "Video not available right now"); return; }
        if (placement.equals("coins") && coinAdsLeft(today) == 0) { r.done(false, "Daily free-coin limit reached"); return; }
        RewardedAd ad = rewarded; rewarded = null; earned = false; showing = true;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { showing = false; if (earned) { if (placement.equals("coins")) p().adCoinN++; p().addStat("ads", 1); } r.done(earned, earned ? "" : "Watch the full video to get the reward"); preload(); }
            @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError e) { showing = false; r.done(false, "Video not available right now"); preload(); } });
        ad.show(act, item -> earned = true);
    }

    /**
     * Natural-break interstitial. `puzzleLive` MUST be false: this is refused while a puzzle is being played.
     * Pacing: not before level 6, every 3rd break, >=3 min apart, not in the first minute. `done` always runs.
     */
    public void breakpoint(int level, boolean puzzleLive, Runnable done) {
        Profile p = p(); long now = System.currentTimeMillis();
        if (puzzleLive || p.noads || level < FIRST_LEVEL || !started.get() || now - t0 < 60_000 || now - p.adLast < MIN_GAP) { done.run(); return; }
        if (++p.adN % EVERY_N != 0) { done.run(); return; }
        if (inter == null) { done.run(); return; }                                   // never block the player
        InterstitialAd ad = inter; inter = null; p.adLast = now; showing = true;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { showing = false; done.run(); preload(); }
            @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError e) { showing = false; done.run(); preload(); } });
        ad.show(act);
    }

    /* ---------------- banner on non-gameplay screens only ---------------- */
    public void banner(boolean on) { wantBanner = on && !p().noads; if (wantBanner) buildBanner(); else killBanner(); }
    private void buildBanner() {
        if (!started.get() || banner != null || !wantBanner || !cfg(BuildConfig.AD_BANNER)) return;
        DisplayMetrics dm = act.getResources().getDisplayMetrics(); banner = new AdView(act); banner.setAdUnitId(BuildConfig.AD_BANNER);
        banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(act, (int) (dm.widthPixels / dm.density)));
        bannerHost.removeAllViews(); bannerHost.addView(banner); banner.loadAd(new AdRequest.Builder().build());
    }
    private void killBanner() { if (banner != null) { bannerHost.removeAllViews(); banner.destroy(); banner = null; } }
    public void pause() { if (banner != null) banner.pause(); }
    public void resume() { if (banner != null) banner.resume(); }
    public void destroy() { killBanner(); }
}
