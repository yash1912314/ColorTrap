package com.colortrap.game;

/** Animation toolkit: easing curves, a damped spring, and a particle pool. Pure Java. */
public final class Fx {
    private Fx() {}

    public static float clamp01(float t) { return t < 0 ? 0 : t > 1 ? 1 : t; }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    public static float easeOutCubic(float t) { t = clamp01(t); float u = 1 - t; return 1 - u * u * u; }
    public static float easeInOutCubic(float t) { t = clamp01(t); return t < .5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2; }
    public static float easeOutBack(float t) { t = clamp01(t); float c1 = 1.70158f, c3 = c1 + 1, u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; }
    public static float easeOutElastic(float t) { t = clamp01(t); if (t == 0 || t == 1) return t; return (float) (Math.pow(2, -9 * t) * Math.sin((t * 10 - .75) * (2 * Math.PI / 3)) + 1); }
    /** Cubic Bezier point (1-D). */
    public static float bez(float a, float b, float c, float d, float t) { float u = 1 - t; return u * u * u * a + 3 * u * u * t * b + 3 * u * t * t * c + t * t * t * d; }

    /** Under-damped spring: gives selection lifts a lively overshoot. */
    public static final class Spring {
        public float x, v, target;
        public Spring(float x) { this.x = x; target = x; }
        public void step(float dt) {
            dt = Math.min(dt, 1f / 30f);
            v += (target - x) * 420f * dt; v *= (float) Math.exp(-14f * dt); x += v * dt;
            if (Math.abs(target - x) < .0008f && Math.abs(v) < .01f) { x = target; v = 0; }
        }
    }

    public static final int CIRCLE = 0, RECT = 1, SPARK = 2;
    /** Fixed-size particle pool (no allocation in the frame loop). */
    public static final class Particles {
        public final int cap;
        public final float[] x, y, vx, vy, life, max, size, rot, vr; public final int[] color, shape; public int count;
        private long seed = 12345;
        public Particles(int cap) { this.cap = cap; x = new float[cap]; y = new float[cap]; vx = new float[cap]; vy = new float[cap]; life = new float[cap]; max = new float[cap]; size = new float[cap]; rot = new float[cap]; vr = new float[cap]; color = new int[cap]; shape = new int[cap]; }
        private float rnd() { seed = seed * 6364136223846793005L + 1442695040888963407L; return ((seed >>> 33) & 0x7FFFFFFF) / (float) 0x7FFFFFFF; }
        public float rand(float a, float b) { return a + (b - a) * rnd(); }
        public void emit(float px, float py, float vxx, float vyy, float life0, float sz, int col, int shp) {
            int i = -1; for (int k = 0; k < count; k++) if (life[k] <= 0) { i = k; break; }
            if (i < 0) { if (count >= cap) return; i = count++; }
            x[i] = px; y[i] = py; vx[i] = vxx; vy[i] = vyy; life[i] = max[i] = life0; size[i] = sz; color[i] = col; shape[i] = shp; rot[i] = rnd() * 6.28f; vr[i] = (rnd() - .5f) * 12;
        }
        /** Radial burst of sparks/dots. */
        public void burst(float cx, float cy, int n, int col, float speed, float sz) {
            for (int k = 0; k < n; k++) { float a = rnd() * 6.2832f, s = speed * (.4f + rnd() * .8f); emit(cx, cy, (float) Math.cos(a) * s, (float) Math.sin(a) * s - speed * .3f, .5f + rnd() * .5f, sz * (.5f + rnd()), col, k % 3 == 0 ? SPARK : CIRCLE); }
        }
        /** Confetti shower falling from the top. */
        public void confetti(float w, int n, int[] cols, float dp) {
            for (int k = 0; k < n; k++) emit(rnd() * w, -rnd() * 60 * dp, (rnd() - .5f) * 120 * dp, (120 + rnd() * 200) * dp, 2f + rnd() * 1.6f, (4 + rnd() * 5) * dp, cols[k % cols.length], RECT);
        }
        public void update(float dt, float gravity) {
            for (int i = 0; i < count; i++) { if (life[i] <= 0) continue; life[i] -= dt; vy[i] += gravity * dt; x[i] += vx[i] * dt; y[i] += vy[i] * dt; rot[i] += vr[i] * dt; }
        }
        public boolean any() { for (int i = 0; i < count; i++) if (life[i] > 0) return true; return false; }
        public void clear() { for (int i = 0; i < count; i++) life[i] = 0; }
    }
}
