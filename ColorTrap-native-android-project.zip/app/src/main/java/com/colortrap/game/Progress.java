package com.colortrap.game;

import java.util.ArrayList;
import java.util.List;

/** Rewards, missions, weekly challenges, badges and milestones (port of the verified web logic). */
public final class Progress {
    private Progress() {}

    public static final class Reward { public boolean first; public int coins, hints, tubes, undos; public List<String> label = new ArrayList<>(); public List<Integer> amount = new ArrayList<>(); void line(String l, int a) { label.add(l); amount.add(a); coins += a; } }

    /** v6 paid 50 coins on EVERY clear (infinite farming). Now: first clear pays; replays pay only for NEW stars. */
    public static Reward levelReward(Profile p, Engine.Level L, int stars) {
        int prev = p.stars[L.n]; Reward r = new Reward(); r.first = prev == 0;
        if (r.first) {
            r.line("First clear", 50); r.line(stars + (stars > 1 ? " stars" : " star"), stars * 10);
            int ch = 0; for (String m : new String[]{"moves", "time", "noundo", "nohint"}) if (L.has(m)) ch++;
            if (ch > 0) r.line("Challenge bonus", ch * 20);
            if (L.boss) { r.line("Boss level", 100); r.hints += 2; }
        } else if (stars > prev) r.line("New stars", (stars - prev) * 15);
        return r;
    }

    /* ---- time periods ---- */
    public static void ensurePeriods(Profile p, String today, String week) {
        if (!today.equals(p.dmDate)) { p.dmDate = today; p.dmP.clear(); p.dmC.clear(); }
        if (!week.equals(p.wkId)) { p.wkId = week; p.wkP.clear(); p.wkC.clear(); }
    }
    public static void event(Profile p, String stat, int n, String today, String week) {
        ensurePeriods(p, today, week);
        p.dmP.put(stat, (p.dmP.containsKey(stat) ? p.dmP.get(stat) : 0) + n); p.wkP.put(stat, (p.wkP.containsKey(stat) ? p.wkP.get(stat) : 0) + n);
    }

    /* ---- quests ---- */
    public static final class Quest { public final String id, stat, title; public final int goal, coins, hints, tubes;
        Quest(String id, String stat, int goal, int coins, String title, int hints, int tubes) { this.id = id; this.stat = stat; this.goal = goal; this.coins = coins; this.title = title; this.hints = hints; this.tubes = tubes; } }
    private static Quest q(String id, String stat, int goal, int coins, String t) { return new Quest(id, stat, goal, coins, t, 0, 0); }
    private static final Quest[] POOL = {
        q("clear3", "clear", 3, 40, "Clear 3 levels"), q("clear5", "clear", 5, 70, "Clear 5 levels"), q("star4", "star", 4, 40, "Earn 4 stars"),
        q("tube12", "tube", 12, 35, "Complete 12 tubes"), q("chal1", "chal", 1, 60, "Clear a challenge level"), q("hf2", "hintfree", 2, 45, "Clear 2 levels without hints"),
        q("daily1", "daily", 1, 30, "Solve today's daily puzzle"), q("play4", "played", 4, 30, "Play 4 levels")
    };
    public static final Quest[] WEEKLY = {
        new Quest("w_clear15", "clear", 15, 300, "Clear 15 levels this week", 0, 0),
        new Quest("w_star25", "star", 25, 350, "Earn 25 stars this week", 3, 0),
        new Quest("w_chal4", "chal", 4, 450, "Clear 4 challenge levels", 0, 2)
    };
    public static Quest[] dailyMissions(String today) {
        Engine.Rng r = new Engine.Rng(Engine.hashStr(today)); ArrayList<Quest> pool = new ArrayList<>();
        for (Quest x : POOL) pool.add(x);
        ArrayList<Quest> out = new ArrayList<>();
        for (int i = 0; i < pool.size(); i++) if (pool.get(i).id.equals("daily1")) { out.add(pool.remove(i)); break; }
        while (out.size() < 3) out.add(pool.remove((int) (r.next() * pool.size())));
        return out.toArray(new Quest[0]);
    }
    public static int prog(java.util.Map<String, Integer> m, Quest q) { Integer v = m.get(q.stat); return Math.min(q.goal, v == null ? 0 : v); }
    public static Quest claimQuest(Profile p, boolean daily, String id, String today, String week) {
        ensurePeriods(p, today, week);
        Quest[] list = daily ? dailyMissions(today) : WEEKLY; java.util.Map<String, Integer> pr = daily ? p.dmP : p.wkP, cl = daily ? p.dmC : p.wkC;
        for (Quest x : list) if (x.id.equals(id)) {
            if (cl.containsKey(id) || prog(pr, x) < x.goal) return null;
            cl.put(id, 1); p.coins += x.coins; p.hints += x.hints; p.tubes += x.tubes; return x;
        }
        return null;
    }

    /* ---- badges ---- */
    public static final class Badge { public final String id, title, desc; public final int coins; public final String own;
        Badge(String id, String t, String d, int c, String own) { this.id = id; title = t; desc = d; coins = c; this.own = own; } }
    public static final Badge[] BADGES = {
        new Badge("first", "First Pour", "Clear your first level", 30, null), new Badge("c10", "Getting Warm", "Clear 10 levels", 60, null),
        new Badge("c50", "Veteran", "Clear 50 levels", 200, null), new Badge("c100", "Centurion", "Clear 100 levels", 400, null),
        new Badge("star50", "Star Collector", "Collect 50 stars", 120, null), new Badge("star3x20", "Perfectionist", "Get 3 stars on 20 levels", 250, null),
        new Badge("boss3", "Boss Slayer", "Beat 3 boss levels", 150, "U:Obsidian"), new Badge("hf10", "No Hints Needed", "Clear 10 levels without a hint", 150, null),
        new Badge("lock3", "Locksmith", "Clear 3 levels with locked tubes", 100, null), new Badge("ice3", "Ice Breaker", "Clear 3 levels with frozen tubes", 100, null),
        new Badge("time3", "Speed Demon", "Win 3 time-attack levels", 120, null), new Badge("daily7", "Daily Devotee", "Solve 7 daily puzzles", 150, null),
        new Badge("streak7", "Full Week", "Finish a 7-day login streak", 100, null), new Badge("all", "Grand Master", "Clear all 150 levels", 1000, null)
    };
    private static boolean met(Profile p, String id) {
        switch (id) {
            case "first": return p.cleared() >= 1; case "c10": return p.cleared() >= 10; case "c50": return p.cleared() >= 50; case "c100": return p.cleared() >= 100;
            case "star50": return p.totalStars() >= 50; case "star3x20": { int c = 0; for (int i = 1; i <= Engine.LEVELS; i++) if (p.stars[i] == 3) c++; return c >= 20; }
            case "boss3": return p.stat("boss") >= 3; case "hf10": return p.stat("hintFree") >= 10; case "lock3": return p.stat("locked") >= 3; case "ice3": return p.stat("frozen") >= 3;
            case "time3": return p.stat("timeWins") >= 3; case "daily7": return p.stat("dailies") >= 7; case "streak7": return p.stat("streak") >= 1; case "all": return p.cleared() >= Engine.LEVELS;
        } return false;
    }
    public static List<Badge> checkBadges(Profile p) { List<Badge> fresh = new ArrayList<>(); for (Badge b : BADGES) if (!p.ach.containsKey(b.id) && met(p, b.id)) { p.ach.put(b.id, 1); fresh.add(b); } return fresh; }
    public static Badge claimBadge(Profile p, String id) {
        for (Badge b : BADGES) if (b.id.equals(id)) { Integer s = p.ach.get(id); if (s == null || s != 1) return null; p.ach.put(id, 2); p.coins += b.coins; if (b.own != null) p.own.add(b.own); return b; }
        return null;
    }

    /* ---- milestones ---- */
    public static final class Milestone { public final String id, title; public final boolean byLevels; public final int at, coins, hints, tubes, undos; public final String own;
        Milestone(String id, boolean lv, int at, int coins, int hints, int tubes, int undos, String own, String t) { this.id = id; byLevels = lv; this.at = at; this.coins = coins; this.hints = hints; this.tubes = tubes; this.undos = undos; this.own = own; title = t; } }
    public static final Milestone[] MILESTONES = {
        new Milestone("m10", true, 10, 100, 0, 0, 0, "U:Crystal", "Crystal tubes"), new Milestone("m25", true, 25, 200, 3, 0, 0, null, "3 hints"),
        new Milestone("s50", false, 50, 150, 0, 0, 0, "B:Aurora", "Aurora board"), new Milestone("m50", true, 50, 400, 0, 0, 0, "B:Royal", "Royal board"),
        new Milestone("m75", true, 75, 500, 0, 3, 0, null, "3 extra tubes"), new Milestone("m100", true, 100, 800, 0, 0, 0, "B:Midnight", "Midnight board"),
        new Milestone("m125", true, 125, 1000, 5, 0, 5, null, "5 hints + 5 undos"), new Milestone("m150", true, 150, 1500, 0, 0, 0, null, "Legend status")
    };
    public static int value(Profile p, Milestone m) { return m.byLevels ? p.cleared() : p.totalStars(); }
    public static Milestone claimMilestone(Profile p, String id) {
        for (Milestone m : MILESTONES) if (m.id.equals(id)) {
            if (p.ms.containsKey(id) || value(p, m) < m.at) return null;
            p.ms.put(id, 1); p.coins += m.coins; p.hints += m.hints; p.tubes += m.tubes; p.undos += m.undos; if (m.own != null) p.own.add(m.own); return m;
        }
        return null;
    }
    public static int pending(Profile p, String today, String week) {
        ensurePeriods(p, today, week); int n = 0;
        for (Milestone m : MILESTONES) if (!p.ms.containsKey(m.id) && value(p, m) >= m.at) n++;
        for (Badge b : BADGES) { Integer s = p.ach.get(b.id); if (s != null && s == 1) n++; }
        for (Quest x : dailyMissions(today)) if (!p.dmC.containsKey(x.id) && prog(p.dmP, x) >= x.goal) n++;
        for (Quest x : WEEKLY) if (!p.wkC.containsKey(x.id) && prog(p.wkP, x) >= x.goal) n++;
        return n;
    }
}
