# Native app: no reflection needed. AdMob ships its own consumer rules.
