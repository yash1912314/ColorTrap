# Color Trap — native Android app (no WebView, no HTML)

Pure Java + Canvas. The whole UI is drawn natively at 60 fps with spring physics, arcing pour animations, squash-and-bounce landings, particles/confetti, animated stars and coin count-ups, and screen/sheet transitions. Sounds are synthesized in code; icons are vector paths, so the app has **no image/audio assets** and stays tiny (expect ~1 MB without ads, a few MB with AdMob).

## Get an APK (two ways)
**A. No installs — GitHub builds it for you**
1. Create a GitHub repo and upload this whole folder (keep the `.github` folder).
2. Open the repo's **Actions** tab → **Build APK** → *Run workflow*.
3. When it's green, open the run and download the **ColorTrap-debug-apk** artifact. Unzip → install `app-debug.apk` on your phone (allow "install unknown apps").
**B. Android Studio:** *File → Open* this folder, let Gradle sync, press Run (or *Build → Build APK*).
Debug builds use Google's public **test ad units** (safe to click).

## Verified here (tools/run-tests.sh)
- Pure-Java engine/solver is a port of the web engine and **matches it exactly**: identical generator output for the same seeds; all **150 levels** parse, replay to a win, and re-solve.
- Rewards/anti-farming, daily/weekly missions, badges, milestones, checksummed save + backup recovery, tamper/garbage handling: all unit-tested.
- The **entire app compiles** against API stubs, and the real `GameView` was driven headlessly through: tutorial, locked & frozen levels, move-limit and time-attack failure, pause/clock freeze, hints/undo/extra tube, daily, shop, missions, settings, Back-button logic — plus **60,000 random inputs with 0 exceptions**.
- Every screen was rendered with the real drawing code (see `preview/`) and layout bugs found that way were fixed.

## NOT verified (I had no Android SDK/device)
- It has **never run on a real Android device or been compiled by the real SDK**. API stubs reflect my knowledge of Android/AdMob signatures; expect to fix small compile errors (paste them to me).
- AdMob/consent code, SoundPool playback, haptics, insets/edge-to-edge, and real-device frame rate are untested.
- Gradle/AGP versions are best-effort (`8.9.1`, compileSdk 36 with a suppress flag): if sync complains, accept Android Studio's suggested upgrades.
- Fonts are system Roboto (the web version used Google fonts). Text widths were checked with a wider font, so they should fit.

## Not ported from the web version (deliberately)
Fake ranks/duel/profile photo (they were simulated — will return when a real backend exists), background music, and **old save data** (the WebView's localStorage can't be read by a native app). Remove-ads purchase still needs Play Billing.

## Release
Set your real AdMob IDs in `app/build.gradle` (release block + manifestPlaceholders), create a keystore (`keystore.properties.example`), run `gradle bundleRelease` for the Play `.aab`. See `docs/` in the earlier package for privacy policy, Data safety and store listing.
