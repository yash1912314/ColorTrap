# Release checklist
1. Open `android/` in Android Studio; accept SDK/Gradle upgrades. Fix any compile errors in `AdBridge.java`/`MainActivity.java`.
2. Run **debug** on a real phone: check save/restore, Back button, photo picker, test ads (rewarded, interstitial after level ≥6 / every 3rd clear / 3 min gap, banner on Levels/Shop/Ranks/Missions only, **none during a puzzle**).
3. In AdMob console: create the app + 3 ad units; put real IDs in `app/build.gradle` (release block **and** manifestPlaceholders). Configure consent (Privacy & messaging). Keep using test units until approved; never click your own live ads.
4. Create an upload keystore (`keytool -genkeypair -v -keystore colortrap-upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`), fill `keystore.properties`, back the keystore up safely.
5. `./gradlew bundleRelease` → `app/build/outputs/bundle/release/app-release.aab`. Enrol in Play App Signing.
6. Keep `applicationId com.colortrap.game`; `versionCode` must exceed any build already uploaded.
7. Play Console: store listing, screenshots, privacy policy URL, Data safety, content rating, target audience, ads declaration. Run an internal test track first; check the pre-launch report for crashes.
8. If you add Remove-ads: use Play Billing Library 8+ (current requirement), create the in-app product `remove_ads`, implement `AndroidBilling.purchase()` and call `CTAds._billing(true)` only after server/Play-verified purchase.
9. Re-verify the current target-API deadline before every release.
10. Test on small (320dp), normal, tablet, and Android 8 → 16 devices; low-RAM device for memory.
