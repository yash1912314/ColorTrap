# Online features — architecture plan (nothing here is implemented or faked)
Today: ranks and duels use **simulated** players; they are labelled "Preview"/"Simulated" in the UI.
**Backend (suggested):** Firebase Auth (anonymous → Google sign-in) + Cloud Firestore/Functions, or a small REST service + Postgres/Redis.
**Anti-cheat core — server-side validation:** the client submits `{levelId|matchId, seed, moves[]}`; the server re-runs `js/engine.js` (pure JS, already deterministic and Node-testable) to replay the moves, rejects illegal/unsolved/too-fast runs, and computes score itself. Never trust a client-sent score.
**Leaderboards:** Redis sorted sets (or Firestore counters) for all-time, weekly (ISO week id, same `weekId()` as the client) and monthly boards; friends board = filter by friend list.
**Profiles:** `{uid, displayName, country, avatarUrl, stats}`; photo upload to cloud storage with moderation. Needs a privacy-policy and Data-safety update.
**Matchmaking:** server issues a shared seed → both clients solve the same puzzle; server timestamps start/finish; ties broken by validated move count. Elo/trophy update server-side. Match history table.
**Client hook:** replace the stubs behind `board()` and `A.find` with an `Online` service (`available:false` until reachable); keep offline play and the local save unchanged.
