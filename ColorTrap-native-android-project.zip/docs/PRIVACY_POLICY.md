# Privacy Policy — Color Trap  (TEMPLATE: review, fill brackets, host at a public URL)
Last updated: [date]    Developer: [name / company]    Contact: [email]

**Gameplay data stays on your device.** Level progress, coins, settings, your display name and optional profile photo are stored locally on your phone. We do not run a server and do not receive this data. Uninstalling the app deletes it.

**Advertising.** Color Trap shows ads provided by Google AdMob (unless you purchase "Remove ads", if offered). AdMob may collect and use: your device's advertising ID, IP address (approximate location), device and app information, and ad interaction/diagnostic data, to serve and measure ads, prevent fraud and (where you consent) personalise ads. In regions such as the EEA/UK, we ask for your consent first and you can change it any time in **Settings → Privacy & ad choices**. Google's practices: https://policies.google.com/privacy and https://policies.google.com/technologies/partner-sites
You can reset or disable your advertising ID in Android settings (Settings → Privacy → Ads).

**Children.** Color Trap is [not directed to children under 13 / directed to ... — decide before publishing; see DATA_SAFETY_AND_RATING.md]. We do not knowingly collect personal information from children.

**Your choices & deletion.** Clear app data or uninstall to remove all local data. For ad-data requests contact Google or us at [email].

**Changes.** We will post updates on this page.
