# Play Store listing (draft — edit freely)
**Title (≤30):** Color Trap: Sort Puzzle
**Short description (≤80):** Sort colors, beat locked & frozen tubes, and climb 150 levels.
**Full description (≤4000):**
Color Trap is a calm-but-clever color sorting puzzle. Pour balls between tubes until every tube holds a single color.

• 150 hand-balanced levels — every one verified solvable
• Fresh twists: locked tubes, frozen tubes, move limits, time attack, no-undo and no-hint challenges, boss levels
• Daily puzzle, daily missions and weekly challenges
• Badges and milestone rewards that unlock new tube skins and boards
• Color-blind friendly palette and number marks
• Plays fully offline — no account needed
• Optional rewarded videos for bonus coins or hints. Never forced, never during a puzzle.

Think. Sort. Win.
**Category:** Games → Puzzle  **Tags:** puzzle, casual, offline
**Graphics:** `store/icon-512.png`, `store/feature-graphic-1024x500.png`, phone screenshots `store/1…6-*.png` (1080×1920)
**Note:** Don't describe ranks/duels as "online multiplayer" — they are simulated previews.
