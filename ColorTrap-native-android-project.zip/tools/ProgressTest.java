import com.colortrap.game.*;
import java.nio.file.*;
import java.util.*;
public class ProgressTest {
    static int fails = 0; static void ok(boolean c, String m) { System.out.println((c ? "PASS " : "FAIL ") + m); if (!c) fails++; }
    static class Mem implements SaveManager.Store { Map<String,String> m = new HashMap<>(); boolean full; public String get(String k) { return m.get(k); } public boolean put(String k, String v) { if (full) return false; m.put(k, v); return true; } }
    public static void main(String[] a) throws Exception {
        Engine.Level[] L = Engine.parseLevels(new String(Files.readAllBytes(Paths.get(a[0]))));
        Profile p = new Profile();
        // anti-farming
        Progress.Reward r = Progress.levelReward(p, L[1], 3); ok(r.first && r.coins == 50 + 30, "first clear 3 stars pays 80 (got " + r.coins + ")");
        p.stars[1] = 3; r = Progress.levelReward(p, L[1], 3); ok(!r.first && r.coins == 0, "replay at same stars pays 0");
        p.stars[1] = 1; r = Progress.levelReward(p, L[1], 3); ok(r.coins == 30, "replay improving 1->3 stars pays 30");
        Engine.Level boss = L[10]; Progress.Reward br = Progress.levelReward(new Profile(), boss, 2); ok(br.hints == 2 && br.coins >= 170, "boss first clear pays bonus + hints (" + br.coins + ")");
        // quests/badges/milestones cannot be claimed twice or early
        String day = "2026-11-18", wk = "2026-W47";
        Progress.event(p, "clear", 5, day, wk); Progress.Quest[] dm = Progress.dailyMissions(day); ok(dm.length == 3 && dm[0].id.equals("daily1"), "3 daily missions, deterministic");
        ok(Arrays.equals(Arrays.stream(dm).map(x -> x.id).toArray(), Arrays.stream(Progress.dailyMissions(day)).map(x -> x.id).toArray()), "same missions all day");
        ok(Progress.claimQuest(p, false, "w_clear15", day, wk) == null, "weekly cannot be claimed early");
        Progress.event(p, "clear", 10, day, wk); int c0 = p.coins; ok(Progress.claimQuest(p, false, "w_clear15", day, wk) != null && p.coins == c0 + 300, "weekly claim pays once");
        ok(Progress.claimQuest(p, false, "w_clear15", day, wk) == null, "weekly cannot be claimed twice");
        ok(Progress.pending(p, day, wk) >= 0, "pending computes");
        Progress.ensurePeriods(p, "2026-11-19", wk); ok(p.dmP.isEmpty() && !p.wkP.isEmpty(), "daily resets, weekly persists same week");
        Progress.ensurePeriods(p, "2026-11-23", "2026-W48"); ok(p.wkP.isEmpty(), "weekly resets next week");
        Profile q = new Profile(); for (int i = 1; i <= 10; i++) q.stars[i] = 3;
        java.util.List<Progress.Badge> fb = Progress.checkBadges(q); ok(fb.size() == 2 && q.ach.containsKey("c10") && !q.ach.containsKey("star50"), "badges: exactly First Pour + Getting Warm at 10 clears"); ok(Progress.claimMilestone(q, "m10") != null && q.own.contains("U:Crystal"), "milestone unlocks Crystal tubes");
        ok(Progress.claimMilestone(q, "m10") == null, "milestone not claimable twice"); ok(Progress.claimMilestone(q, "m25") == null, "milestone not claimable early");
        // save round-trip + corruption recovery
        Profile s = new Profile(); s.coins = 1234; s.unl = 9; s.stars[3] = 2; s.theme = "Neon"; s.own.add("T:Neon"); s.addStat("clears", 4); s.dmP.put("clear", 2); s.adLast = 1700000000123L;
        Mem mem = new Mem(); SaveManager sm = new SaveManager(mem); sm.load(); sm.save(s); s.coins = 1300; sm.save(s);
        Profile t = new SaveManager(mem).load(); ok(t.coins == 1300 && t.unl == 9 && t.stars[3] == 2 && t.theme.equals("Neon") && t.own.contains("T:Neon") && t.stat("clears") == 4 && t.dmP.get("clear") == 2 && t.adLast == 1700000000123L, "save round-trips every field");
        mem.m.put(SaveManager.MAIN, "garbage"); SaveManager s2 = new SaveManager(mem); t = s2.load(); ok(t.coins == 1234 && s2.recovered, "corrupt primary -> backup restored (coins " + t.coins + ")");
        String good = mem.get(SaveManager.BAK); mem.m.put(SaveManager.MAIN, good.replace("coins=1234", "coins=9999")); t = new SaveManager(mem).load(); ok(t.coins != 9999, "tampered checksum rejected");
        mem.m.put(SaveManager.MAIN, "x"); mem.m.put(SaveManager.BAK, "y"); t = new SaveManager(mem).load(); ok(t.coins == 300, "all corrupt -> defaults, no crash");
        mem.full = true; ok(!new SaveManager(mem).save(s), "storage-full is reported, not thrown");
        Profile bad = Profile.parse("coins=-5\nunl=99999\nstars=1:9,500:2,x:y\nday=77\n"); ok(bad.coins == 0 && bad.unl == Engine.LEVELS && bad.stars[1] == 3 && bad.day == 6, "hostile/garbage values are clamped");
        System.out.println(fails == 0 ? "ALL PROGRESS/SAVE TESTS PASSED" : fails + " FAILURES"); System.exit(fails == 0 ? 0 : 1);
    }
}
