package com.colortrap.game;

import android.graphics.Canvas;
import android.os.SystemClock;
import java.util.*;

/** Headless integration test: runs the REAL GameView logic (everything except pixels) through full play sessions. */
public class GameSim {
    static int fails = 0; static void ok(boolean c, String m) { System.out.println((c ? "PASS " : "FAIL ") + m); if (!c) fails++; }
    static class H implements GameView.Host {
        Profile p = new Profile(); int saves; Map<String, String> mem = new HashMap<>(); Ads ads; Sfx sfx; GameView v;
        public Profile profile() { return p; } public void save() { saves++; } public void vibrate(long ms) { } public Ads ads() { return ads; } public Sfx sfx() { return sfx; } public void exitApp() { } public void resetProgress() { p = new Profile(); }
    }
    static H h; static GameView v; static Canvas cv = new Canvas();
    static void frames(float sec) { int n = (int) (sec / .016f) + 1; for (int i = 0; i < n; i++) { SystemClock.ms += 16; v.onDraw(cv); } }
    static void tap(int i) { v.act("tube", i); }
    static void playSolution(Engine.Level L) {
        for (int[] m : L.sol) { tap(m[0]); frames(.25f); tap(m[1]); frames(1.1f); }
    }
    public static void main(String[] a) throws Exception {
        h = new H(); h.ads = new Ads(new android.app.Activity() { }, new android.widget.FrameLayout(null), () -> h.p); h.sfx = new Sfx(new android.app.Activity() { });
        v = new GameView(new android.app.Activity() { }, h); v.setInsets(60, 0); v.onSizeChanged(1080, 2200, 0, 0);
        // --- boot ---
        frames(.5f); ok(v.screen == GameView.SPLASH, "starts on splash"); frames(1.6f); ok(v.screen == GameView.HOME, "splash -> home");
        for (String s : new String[]{"play", "daily", "missions", "shop", "settings"}) { v.act(s, 0); frames(.5f); }
        for (int t = 0; t < 5; t++) { v.act("shoptab", t); frames(.2f); } for (int t = 0; t < 4; t++) { v.act("misstab", t); frames(.2f); }
        v.goTo(GameView.HOME); frames(.4f); ok(true, "all menu screens render without exceptions");
        // --- level 1 with tutorial, real taps ---
        int coins0 = h.p.coins; v.startLevel(1); frames(.5f); ok(v.screen == GameView.GAME && v.tut == 0, "level 1 starts with tutorial");
        tap(5); frames(.3f); ok(v.sel < 0, "tutorial rejects a wrong tube (accident protection)");
        playSolution(v.levels[1]); frames(2f);
        ok(v.dlg == GameView.D_WIN && h.p.stars[1] > 0, "level 1 solved by taps -> win dialog, stars saved"); ok(h.p.coins - coins0 >= 80 - 0 && h.p.coins - coins0 <= 100, "first-clear coins paid (" + (h.p.coins - coins0) + ")"); ok(h.p.tut == 1, "tutorial marked complete"); ok(h.p.unl == 2, "level 2 unlocked");
        // --- anti farming ---
        v.act("next", 0); frames(.5f); ok(v.levelNo == 2 && v.screen == GameView.GAME, "Next level starts level 2");
        v.act("restart", 0); frames(.3f); v.startLevel(1); frames(.3f); int c1 = h.p.coins; playSolution(v.levels[1]); frames(2f); ok(h.p.coins == c1 || h.p.coins - c1 <= 30, "replay does not farm coins (delta " + (h.p.coins - c1) + ")");
        // --- obstacle levels: locked, frozen ---
        int lockedLv = 0, frozenLv = 0, moveLv = 0, timeLv = 0; for (int n = 1; n <= 150; n++) { Engine.Level L = v.levels[n]; if (lockedLv == 0 && L.has("locked") && !L.has("time") && !L.has("moves")) lockedLv = n; if (frozenLv == 0 && L.has("frozen") && !L.has("time") && !L.has("moves")) frozenLv = n; if (moveLv == 0 && L.limitMoves > 0) moveLv = n; if (timeLv == 0 && L.limitTime > 0) timeLv = n; }
        h.p.unl = 150; v.startLevel(lockedLv); frames(.4f); int lk = v.gs.lock[0]; v.act("tube", lk); frames(.3f); ok(v.sel < 0 && v.toastMsg.contains("Locked"), "tapping a locked tube is refused with feedback");
        playSolution(v.levels[lockedLv]); frames(2f); ok(v.dlg == GameView.D_WIN, "locked-tube level " + lockedLv + " solvable via taps");
        v.startLevel(frozenLv); frames(.4f); playSolution(v.levels[frozenLv]); frames(2f); ok(v.dlg == GameView.D_WIN, "frozen-tube level " + frozenLv + " solvable via taps");
        // --- move limit -> fail dialog -> rewarded unavailable (no ads) ---
        v.startLevel(moveLv); frames(.4f); v.gs.moves = v.limitMoves() - 1; int[] mv = null; for (int i = 0; i < v.gs.T.n && mv == null; i++) for (int j = 0; j < v.gs.T.n; j++) if (Engine.pourN(v.gs, i, j) > 0) { mv = new int[]{i, j}; break; }
        tap(mv[0]); frames(.3f); tap(mv[1]); frames(2f); ok(v.dlg == GameView.D_FAIL && v.dlgArg.equals("moves"), "move limit reached -> fail dialog"); ok(!h.ads.rewardedReady(), "no ads without SDK -> offer hidden, game not blocked");
        v.act("restart", 0); frames(.4f); ok(v.dlg == GameView.D_NONE && v.gs.moves == 0, "Try again restarts cleanly");
        // --- time attack ---
        v.startLevel(timeLv); frames(.4f); float t0 = v.timeLeft(); frames(3f); ok(v.timeLeft() < t0 - 2.5f, "time attack clock counts down"); v.act("pause", 0); frames(.2f); float tp = v.timeLeft(); frames(5f); ok(Math.abs(v.timeLeft() - tp) < .3f, "clock is frozen while paused");
        v.act("resume", 0); frames(v.timeLeft() + 1f); ok(v.dlg == GameView.D_FAIL && v.dlgArg.equals("time"), "time runs out -> fail dialog");
        // --- undo / hint / extra tube ---
        v.startLevel(3); frames(.4f); int hints0 = h.p.hints; v.act("hint", 0); ok(h.p.hints == hints0 - 1 && v.hintA >= 0, "hint consumes one and highlights a move"); int fa = v.hintA, fb = v.hintB; tap(fa); frames(.3f); tap(fb); frames(1.2f); int mvs = v.gs.moves; v.act("undo", 0); ok(v.gs.moves == mvs - 1, "undo reverts the move");
        int tubes0 = v.gs.T.n; v.act("extra", 0); ok(v.gs.T.n == tubes0 + 1, "extra tube adds a tube"); v.act("undo", 0); v.act("extra", 0); ok(v.gs.T.n == tubes0 + 1, "only one extra tube per level");
        // --- hint-based solve: follow hints all the way ---
        v.startLevel(4); frames(.4f); h.p.hints = 999; int guard = 0; while (v.dlg == GameView.D_NONE && guard++ < 200) { v.act("hint", 0); if (v.hintA < 0) break; int x = v.hintA, y = v.hintB; v.hintA = -1; tap(x); frames(.25f); tap(y); frames(1.1f); } ok(v.dlg == GameView.D_WIN, "level 4 solved purely by following hints (" + guard + " steps)");
        // --- daily ---
        v.goTo(GameView.HOME); v.act("claimday", 0); ok(h.p.last.equals(v.today()) && h.p.day == 1, "daily login reward claimed once"); int cc = h.p.coins; v.act("claimday", 0); ok(h.p.coins == cc, "daily login cannot be claimed twice");
        v.startDaily(); frames(.4f); Engine.State st = v.gs.copy(); Engine.Solve s = Engine.solve(st, 200000); ok(s.ok, "daily puzzle solvable"); for (int[] m : s.moves) { tap(m[0]); frames(.25f); tap(m[1]); frames(1.1f); } frames(2f); ok(v.dlg == GameView.D_WIN && h.p.daily.equals(v.today()), "daily puzzle solved -> reward flagged");
        // --- shop / purchases / settings ---
        h.p.coins = 1000; v.goTo(GameView.SHOP); v.act("shoptab", 0); int idx = Arrays.asList(Catalog.THEMES).indexOf("Candy"); v.act("shopitem", idx); ok(h.p.theme.equals("Candy") && h.p.coins == 1000 - Catalog.THEME_PRICE[idx], "buy + equip a ball theme"); v.act("shoptab", 3); v.act("boost", 0); ok(h.p.hints >= 3, "boost purchase works"); v.act("shoptab", 2); int roy = Arrays.asList(Catalog.BACKS).indexOf("Royal"); h.p.coins = 5000; v.act("shopitem", roy); ok(!h.p.own.contains("B:Royal"), "reward-only board cannot be bought");
        v.act("toggle", 2); ok(h.p.cb, "number marks toggle"); frames(.3f); v.act("toggle", 3); ok(h.p.rm, "reduce motion toggle"); frames(1f);
        // --- missions / badges / milestones claim paths ---
        for (int i = 1; i <= 10; i++) h.p.stars[i] = 3; Progress.checkBadges(h.p); v.goTo(GameView.MISSIONS); v.act("misstab", 3); v.act("claimm", 0); ok(h.p.ms.containsKey("m10") && h.p.own.contains("U:Crystal"), "milestone claim via UI"); v.act("misstab", 2); v.act("claimb", 0); ok(h.p.ach.get("first") == 2, "badge claim via UI");
        // --- back button behaviour ---
        v.goTo(GameView.SHOP); ok(v.onBack() && v.screen == GameView.HOME, "back from shop -> home"); ok(v.onBack(), "home: first back is consumed (shows toast)"); ok(!v.onBack(), "home: second back exits app");
        v.startLevel(5); frames(.4f); ok(v.onBack() && v.dlg == GameView.D_PAUSE, "back in game opens pause"); ok(v.onBack() && v.dlg == GameView.D_NONE, "back again resumes");
        // --- reset ---
        v.goTo(GameView.SETTINGS); v.act("reset", 0); v.act("reset", 0); ok(h.p.coins == 300 && h.p.unl == 1, "reset progress (two taps)");
        // --- SFX synthesis + wav writing ---
        for (int i = 0; i < Sfx.COUNT; i++) { short[] pcm = Sfx.synth(i); ok(pcm.length > 500, "sfx " + i + " synthesised (" + pcm.length + " samples)"); }
        Thread.sleep(300); ok(new java.io.File("/tmp/sfxtest/sfx/s9.wav").exists(), "WAV files written for SoundPool");
        // --- monkey test: 60k random inputs must never throw ---
        Random r = new Random(7); h.p.unl = 150; String[] acts = {"tube", "tube", "tube", "undo", "hint", "extra", "restart", "pause", "resume", "next", "claimq", "lvl", "shopitem", "toggle", "back", "skiptut", "startbrief"}; int ex = 0;
        for (int it = 0; it < 60000; it++) { try { int k = r.nextInt(100);
            if (k < 8) v.startLevel(1 + r.nextInt(150)); else if (k < 10) v.goTo(r.nextInt(8)); else { String act = acts[r.nextInt(acts.length)]; if (act.equals("startbrief")) continue; v.act(act, r.nextInt(18)); }
            if (r.nextInt(3) == 0) frames(r.nextFloat() * .8f); if (r.nextInt(20) == 0) v.onBack(); } catch (Throwable t) { if (ex++ < 3) { System.out.println("EXC " + t); for (int q = 0; q < 6 && q < t.getStackTrace().length; q++) System.out.println("   " + t.getStackTrace()[q]); } } }
        ok(ex == 0, "monkey test: 60000 random actions, " + ex + " exceptions");
        System.out.println(fails == 0 ? "ALL GAMEVIEW SIMULATION TESTS PASSED" : fails + " FAILURES"); System.exit(fails == 0 ? 0 : 1);
    }
}
