package android.graphics;import java.awt.*;import java.awt.geom.*;import java.awt.image.BufferedImage;import java.util.*;
public class Canvas{public Graphics2D g;public BufferedImage img;ArrayDeque<Object[]> st=new ArrayDeque<>();float alpha=1f;
public Canvas(){}public Canvas(BufferedImage i){img=i;g=i.createGraphics();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,RenderingHints.VALUE_STROKE_PURE);}
public void reset(){if(g==null)return;g.setTransform(new AffineTransform());g.setClip(null);g.setComposite(AlphaComposite.SrcOver);st.clear();alpha=1f;}
public int save(){if(g==null)return 0;st.push(new Object[]{g.getTransform(),g.getClip(),alpha});return st.size();}
public void restore(){if(g==null||st.isEmpty())return;Object[] o=st.pop();g.setTransform((AffineTransform)o[0]);g.setClip((Shape)o[1]);alpha=(Float)o[2];}
public void scale(float a,float b){if(g!=null)g.scale(a,b);}public void scale(float a,float b,float px,float py){if(g!=null){g.translate(px,py);g.scale(a,b);g.translate(-px,-py);}}public void translate(float x,float y){if(g!=null)g.translate(x,y);}public void rotate(float d,float px,float py){if(g!=null)g.rotate(Math.toRadians(d),px,py);}
public void clipRect(float l,float t,float r,float b){if(g!=null)g.clip(new Rectangle2D.Float(l,t,r-l,b-t));}
public int saveLayerAlpha(float l,float t,float r,float b,int a){int n=save();alpha*=a/255f;return n;}
void apply(Paint p){g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,Math.max(0,Math.min(1,alpha))));if(p.shader!=null)g.setPaint(p.shader.awt());else g.setPaint(new Color(p.color,true));
int cap=p.cap==Paint.Cap.ROUND?BasicStroke.CAP_ROUND:p.cap==Paint.Cap.SQUARE?BasicStroke.CAP_SQUARE:BasicStroke.CAP_BUTT;int jn=p.join==Paint.Join.ROUND?BasicStroke.JOIN_ROUND:p.join==Paint.Join.BEVEL?BasicStroke.JOIN_BEVEL:BasicStroke.JOIN_MITER;g.setStroke(new BasicStroke(Math.max(.01f,p.sw),cap,jn));}
void draw(Shape s,Paint p){if(g==null)return;apply(p);if(p.style==Paint.Style.STROKE)g.draw(s);else g.fill(s);}
public void drawRoundRect(RectF r,float a,float b,Paint p){draw(new RoundRectangle2D.Float(r.left,r.top,r.width(),r.height(),a*2,b*2),p);}
public void drawRect(float l,float t,float r,float b,Paint p){draw(new Rectangle2D.Float(l,t,r-l,b-t),p);}public void drawRect(RectF r,Paint p){drawRect(r.left,r.top,r.right,r.bottom,p);}
public void drawCircle(float x,float y,float r,Paint p){draw(new Ellipse2D.Float(x-r,y-r,2*r,2*r),p);}public void drawPath(Path pa,Paint p){draw(pa.p,p);}
public void drawLine(float a,float b,float c,float d,Paint p){if(g==null)return;apply(p);g.draw(new Line2D.Float(a,b,c,d));}
public void drawText(String s,float x,float y,Paint p){if(g==null)return;apply(p);g.setFont(p.font());float w=p.measureText(s);float xx=p.align==Paint.Align.CENTER?x-w/2:p.align==Paint.Align.RIGHT?x-w:x;g.drawString(s,xx,y);}}