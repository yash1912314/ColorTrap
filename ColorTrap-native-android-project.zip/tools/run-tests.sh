#!/bin/bash
# Runs every check that does not need the Android SDK. Needs: JDK 17+ and Node (only for the JS cross-check, optional).
set -e; cd "$(dirname "$0")/.."; OUT=$(mktemp -d); JAVAC="javac"; command -v javac >/dev/null || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
SRC=app/src/main/java/com/colortrap/game
echo "== 1. pure-Java rules: progress, rewards, saves =="
$JAVAC -d $OUT $SRC/Engine.java $SRC/Profile.java $SRC/SaveManager.java $SRC/Progress.java tools/ProgressTest.java && java -cp $OUT ProgressTest app/src/main/assets/levels.txt | tail -1
echo "== 2. whole app compiles against Android/AdMob API stubs; headless play-through + 60k random inputs =="
$JAVAC -d $OUT $(find tools/stubs -name "*.java") $(find app/src/main/java -name "*.java") tools/GameSim.java tools/Render.java
java -Djava.awt.headless=true -cp $OUT com.colortrap.game.GameSim | tail -1
echo "== 3. render screens to /tmp/native_shots (Java2D) =="; java -Djava.awt.headless=true -cp $OUT com.colortrap.game.Render
