import com.colortrap.game.Engine;
import com.colortrap.game.Engine.*;
import java.nio.file.*;
public class EngineTest {
    static int fails = 0;
    static void ok(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL: " + m); } }
    public static void main(String[] a) throws Exception {
        // 1) generator output must equal the JS engine's output for the same seeds
        for (String line : Files.readAllLines(Paths.get("/tmp/xcheck.txt"))) {
            String[] f = line.split(";"); Board T = Engine.shuffleLayout(Long.parseLong(f[0]), Integer.parseInt(f[1]), Double.parseDouble(f[2]), 2);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < T.n; i++) { if (i > 0) sb.append('/'); if (T.len[i] == 0) sb.append('_'); else for (int k = 0; k < T.len[i]; k++) { if (k > 0) sb.append(','); sb.append(T.b[i][k]); } }
            ok(sb.toString().equals(f[3]), "JS/Java generator mismatch seed " + f[0]);
        }
        // 2) every shipped level: parse, replay stored solution through rules, and independently re-solve
        String txt = new String(Files.readAllBytes(Paths.get(a[0])));
        Level[] L = Engine.parseLevels(txt); long t0 = System.currentTimeMillis(); int solved = 0;
        for (int n = 1; n <= Engine.LEVELS; n++) {
            Level l = L[n]; ok(l != null, "level " + n + " missing"); if (l == null) continue;
            ok(l.T.n == l.c + 2, "L" + n + " tube count");
            State s = l.newState();
            for (int[] m : l.sol) { int moved = Engine.doPour(s, m[0], m[1]); ok(moved > 0, "L" + n + " illegal stored move"); }
            ok(Engine.isWon(s.T), "L" + n + " stored solution does not win");
            ok(l.sol.length == l.par, "L" + n + " par != sol length");
            if (l.limitMoves > 0) ok(l.limitMoves >= l.par, "L" + n + " move limit below par");
            Solve r = Engine.solve(l.newState(), 200000); ok(r.ok, "L" + n + " Java solver failed (nodes " + r.nodes + ")"); if (r.ok) solved++;
        }
        System.out.println("Java solver solved " + solved + "/150 in " + (System.currentTimeMillis() - t0) + " ms");
        // 3) obstacle rules
        State s = new State(); s.T = new Board(4); int[][] init = {{0,0,0,1},{1,1,1,0},{},{}};
        for (int i = 0; i < 4; i++) { for (int k = 0; k < init[i].length; k++) s.T.b[i][k] = init[i][k]; s.T.len[i] = init[i].length; }
        s.lock = new int[]{1}; ok(Engine.pourN(s, 1, 2) == 0 && Engine.pourN(s, 0, 1) == 0, "locked tube must not pour");
        s.lock = new int[0]; s.frz = new int[]{3, 0, 0, 0}; ok(Engine.pourN(s, 0, 2) == 0, "frozen sealed"); s.moves = 3; ok(Engine.pourN(s, 0, 2) == 1, "thaws at move 3");
        State u = new State(); u.T = new Board(4); int[][] i2 = {{0,0,0},{0},{1,1,1,1},{}}; for (int i = 0; i < 4; i++) { for (int k = 0; k < i2[i].length; k++) u.T.b[i][k] = i2[i][k]; u.T.len[i] = i2[i].length; }
        u.lock = new int[]{3}; Engine.doPour(u, 1, 0); ok(u.unl, "first completed tube unlocks");
        // 4) daily puzzles solvable for a year of dates
        int bad = 0; for (int d = 1; d <= 365; d++) { State q = new State(); q.T = Engine.dailyBoard("2026-" + String.format("%02d", 1 + d / 31) + "-" + String.format("%02d", 1 + d % 28)); if (!Engine.solve(q, 120000).ok) bad++; }
        ok(bad == 0, "daily unsolvable " + bad);
        System.out.println(fails == 0 ? "ALL JAVA ENGINE TESTS PASSED" : fails + " FAILURES"); System.exit(fails == 0 ? 0 : 1);
    }
}
