package com.colortrap.game;

import android.graphics.Canvas;
import android.os.SystemClock;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import javax.imageio.ImageIO;

/** Renders the REAL native GameView to PNG files (Java2D backend) for visual verification. */
public class Render {
    static GameSim.H h; static GameView v; static BufferedImage img; static Canvas cv;
    static void frames(float sec) { int n = (int) (sec / .016f) + 1; for (int i = 0; i < n; i++) { SystemClock.ms += 16; cv.reset(); v.onDraw(cv); } }
    static void shot(String name) throws Exception { frames(.02f); ImageIO.write(img, "png", new File("/tmp/native_shots/" + name + ".png")); }
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true"); new File("/tmp/native_shots").mkdirs();
        int W = 1080, H = 2200; img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB); cv = new Canvas(img);
        GameSim.h = h = new GameSim.H(); h.ads = new Ads(new android.app.Activity() { }, new android.widget.FrameLayout(null), () -> h.p); h.sfx = new Sfx(new android.app.Activity() { });
        v = new GameView(new android.app.Activity() { }, h); v.setInsets(90, 0); v.onSizeChanged(W, H, 0, 0);
        h.p.coins = 1250; h.p.unl = 18; for (int i = 1; i < 18; i++) h.p.stars[i] = i % 3 + 1; h.p.tut = 1;
        frames(.7f); shot("01_splash"); frames(1.6f); frames(.5f); shot("02_home");
        v.act("play", 0); frames(1.4f); shot("03_levels");
        h.p.unl = 60; v.scrollY = -1; v.goTo(GameView.HOME); v.act("play", 0); frames(1.0f); shot("03b_levels_deep");
        h.p.unl = 18; h.p.tut = 0; v.startLevel(1); frames(.6f); shot("04_game_tutorial"); h.p.tut = 1;
        v.startLevel(8); frames(.6f); shot("05_locked_tube");
        v.startLevel(18); frames(.6f); shot("06_frozen_tube");
        v.startLevel(30); frames(.6f); shot("07_big_board_30");
        v.startLevel(60); frames(.6f); shot("07b_big_board_60");
        v.startLevel(3); frames(.5f); int[] m = v.levels[3].sol[0]; v.act("tube", m[0]); frames(.5f); shot("08_selected_lift"); v.act("tube", m[1]); frames(.22f); shot("08b_ball_in_flight"); frames(1f);
        v.startLevel(13); frames(.6f); shot("09_time_attack");
        v.startLevel(2); frames(.3f); v.act("hint", 0); frames(.4f); shot("10_hint_glow");
        v.act("pause", 0); frames(.6f); shot("11_pause");
        v.act("resume", 0); v.startLevel(1); frames(.3f); h.p.tut = 1; v.tut = -1; for (int[] mv : v.levels[1].sol) { v.act("tube", mv[0]); frames(.25f); v.act("tube", mv[1]); frames(1.1f); } frames(1.3f); shot("12_win_dialog");
        v.act("homeafter", 0); frames(.2f); v.act("lvl", 8); frames(.6f); shot("13_level_brief");
        v.act("startbrief", 8); v.openDialog(GameView.D_FAIL, "moves"); frames(.6f); shot("14_fail_dialog");
        v.closeDialog(); v.goTo(GameView.SHOP); for (int t = 0; t < 5; t++) { v.act("shoptab", t); frames(.6f); shot("15_shop_" + t); }
        v.goTo(GameView.MISSIONS); for (int t = 0; t < 4; t++) { v.act("misstab", t); frames(.6f); shot("16_missions_" + t); }
        v.goTo(GameView.SETTINGS); frames(.6f); shot("17_settings"); v.goTo(GameView.DAILY); frames(.6f); shot("18_daily");
        h.p.theme = "Accessible"; h.p.cb = true; v.startLevel(5); frames(.6f); shot("19_accessible_numbers");
        System.out.println("rendered");
    }
}
